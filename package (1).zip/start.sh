#!/bin/bash

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}  Divar Clone - Complete System Setup  ${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    echo -e "${RED}Error: Docker is not installed!${NC}"
    echo "Please install Docker first: https://docs.docker.com/get-docker/"
    exit 1
fi

# Check if Docker Compose is installed
if ! command -v docker-compose &> /dev/null && ! docker compose version &> /dev/null; then
    echo -e "${RED}Error: Docker Compose is not installed!${NC}"
    echo "Please install Docker Compose first: https://docs.docker.com/compose/install/"
    exit 1
fi

echo -e "${YELLOW}Step 1: Creating .env file if not exists...${NC}"
if [ ! -f .env ]; then
    cp .env.example .env
    echo -e "${GREEN}.env file created! Please edit it with your configurations.${NC}"
else
    echo -e "${GREEN}.env file already exists.${NC}"
fi

echo ""
echo -e "${YELLOW}Step 2: Setting up Admin Panel...${NC}"
if [ ! -f admin-panel/.env.local ]; then
    cp admin-panel/.env.example admin-panel/.env.local
    echo -e "${GREEN}Admin Panel .env.local created!${NC}"
fi

echo ""
echo -e "${YELLOW}Step 3: Stopping any running containers...${NC}"
docker-compose down 2>/dev/null || true

echo ""
echo -e "${YELLOW}Step 4: Building Docker images...${NC}"
docker-compose build

echo ""
echo -e "${YELLOW}Step 5: Starting services...${NC}"
docker-compose up -d

echo ""
echo -e "${YELLOW}Step 6: Waiting for services to be ready...${NC}"
sleep 10

echo ""
echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}  Installation Complete!  ${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""
echo -e "${GREEN}Services are running at:${NC}"
echo -e "  - Frontend:      ${YELLOW}http://localhost:3000${NC}"
echo -e "  - Admin Panel:   ${YELLOW}http://localhost:3001${NC}"
echo -e "  - Backend API:   ${YELLOW}http://localhost:5000${NC}"
echo -e "  - PostgreSQL:    ${YELLOW}localhost:5432${NC}"
echo -e "  - Redis:         ${YELLOW}localhost:6379${NC}"
echo -e "  - MinIO:         ${YELLOW}http://localhost:9001${NC}"
echo -e "  - Elasticsearch: ${YELLOW}http://localhost:9200${NC}"
echo ""
echo -e "${GREEN}Admin Panel Credentials:${NC}"
echo -e "  - Username: ${YELLOW}admin${NC}"
echo -e "  - Password: ${YELLOW}Admin@123456${NC}"
echo ""
echo -e "${YELLOW}Useful commands:${NC}"
echo -e "  - View logs:        ${GREEN}docker-compose logs -f${NC}"
echo -e "  - Stop services:    ${GREEN}docker-compose down${NC}"
echo -e "  - Restart services: ${GREEN}docker-compose restart${NC}"
echo ""
