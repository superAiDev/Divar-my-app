# 🚀 Divar Clone - سیستم کامل آگهی آنلاین

<div dir="rtl">

## 📋 فهرست مطالب

- [معرفی](#معرفی)
- [ویژگی‌ها](#ویژگی‌ها)
- [معماری سیستم](#معماری-سیستم)
- [پیش‌نیازها](#پیش‌نیازها)
- [راه‌اندازی سریع](#راه‌اندازی-سریع)
- [راه‌اندازی دستی](#راه‌اندازی-دستی)
- [پیکربندی](#پیکربندی)
- [استقرار در محیط Production](#استقرار-در-محیط-production)
- [مستندات API](#مستندات-api)
- [رفع مشکلات](#رفع-مشکلات)

## 🎯 معرفی

یک پلتفرم کامل و حرفه‌ای برای آگهی‌های خرید و فروش شامل:

- ✅ **اپلیکیشن اصلی**: رابط کاربری مدرن برای کاربران عادی
- ✅ **پنل مدیریت**: داشبورد پیشرفته برای مدیریت کامل سیستم
- ✅ **API Backend**: سرویس‌های RESTful با NestJS
- ✅ **دیتابیس**: PostgreSQL برای ذخیره‌سازی داده‌ها
- ✅ **کش**: Redis برای بهبود سرعت
- ✅ **ذخیره‌سازی فایل**: MinIO برای مدیریت تصاویر
- ✅ **جستجو**: Elasticsearch برای جستجوی پیشرفته

## ✨ ویژگی‌ها

### اپلیکیشن کاربری

- 🔐 احراز هویت کامل (ثبت‌نام، ورود، بازیابی رمز)
- 📝 ثبت و مدیریت آگهی‌ها
- 🔍 جستجوی پیشرفته و فیلترهای هوشمند
- 💬 چت Real-time بین خریدار و فروشنده
- ⭐ نشان‌گذاری و ذخیره آگهی‌های مورد علاقه
- 📍 جستجو بر اساس موقعیت جغرافیایی
- 🖼️ آپلود چندین تصویر برای هر آگهی
- 💳 پرداخت آنلاین برای آگهی‌های ویژه

### پنل مدیریت

- 📊 داشبورد تحلیلی با نمودارهای زنده
- 👥 مدیریت کاربران (بلاک، فعال‌سازی، ارتقا)
- 📋 مدیریت آگهی‌ها (تایید، رد، حذف)
- 🗂️ مدیریت دسته‌بندی‌ها
- 🎨 مدیریت بنرهای تبلیغاتی
- 💰 مدیریت تراکنش‌ها و درآمدها
- ⚙️ تنظیمات کامل سیستم
- 📈 گزارش‌گیری پیشرفته

## 🏗️ معماری سیستم

```
┌─────────────────────────────────────────────────────────────┐
│                     Load Balancer (Nginx)                   │
└──────────────────────┬──────────────────────────────────────┘
                       │
        ┌──────────────┼──────────────┐
        │              │              │
   ┌────▼────┐   ┌────▼────┐   ┌─────▼──────┐
   │Frontend │   │  Admin  │   │  Backend   │
   │ (Next)  │   │  Panel  │   │  (NestJS)  │
   │ :3000   │   │ (Next)  │   │   :5000    │
   └─────────┘   │ :3001   │   └─────┬──────┘
                 └─────────┘         │
                                     │
        ┌────────────────────────────┼────────────────────┐
        │                            │                    │
   ┌────▼────┐              ┌───────▼─────┐      ┌──────▼──────┐
   │PostgreSQL│              │    Redis    │      │    MinIO    │
   │  :5432  │              │    :6379    │      │    :9000    │
   └─────────┘              └─────────────┘      └─────────────┘
                                                          │
                                                  ┌───────▼────────┐
                                                  │ Elasticsearch  │
                                                  │     :9200      │
                                                  └────────────────┘
```

## 📦 پیش‌نیازها

- **Docker** >= 20.10
- **Docker Compose** >= 2.0
- **حداقل رم**: 4GB
- **حداقل فضای دیسک**: 10GB

### نصب Docker

#### Ubuntu/Debian
```bash
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh
sudo usermod -aG docker $USER
```

#### macOS
دانلود و نصب [Docker Desktop](https://www.docker.com/products/docker-desktop)

#### Windows
دانلود و نصب [Docker Desktop](https://www.docker.com/products/docker-desktop)

## 🚀 راه‌اندازی سریع

### گام 1: دانلود پروژه

```bash
# اگر از Git استفاده می‌کنید:
git clone <repository-url>
cd divar-clone-system

# یا فایل ZIP را از دانلود و استخراج کنید
```

### گام 2: اجرای اسکریپت نصب

```bash
chmod +x start.sh
./start.sh
```

این اسکریپت به صورت خودکار:
- فایل‌های `.env` را ایجاد می‌کند
- تمام سرویس‌ها را Build می‌کند
- سیستم را راه‌اندازی می‌کند

### گام 3: دسترسی به سیستم

پس از چند دقیقه، سرویس‌ها در آدرس‌های زیر در دسترس خواهند بود:

- **اپلیکیشن اصلی**: http://localhost:3000
- **پنل مدیریت**: http://localhost:3001
- **Backend API**: http://localhost:5000
- **Swagger API Docs**: http://localhost:5000/api/docs
- **MinIO Console**: http://localhost:9001

#### اطلاعات ورود پنل مدیریت:
- **نام کاربری**: `admin`
- **رمز عبور**: `Admin@123456`

## 🛠️ راه‌اندازی دستی

### گام 1: ایجاد فایل‌های Environment

```bash
# فایل اصلی
cp .env.example .env

# پنل مدیریت
cp admin-panel/.env.example admin-panel/.env.local
```

### گام 2: ویرایش فایل‌های .env

فایل `.env` را ویرایش کرده و مقادیر زیر را تنظیم کنید:

```env
POSTGRES_PASSWORD=your_secure_password
REDIS_PASSWORD=your_redis_password
JWT_SECRET=your_jwt_secret_key
ADMIN_PASSWORD=your_admin_password
```

### گام 3: Build و اجرای سرویس‌ها

```bash
# Build تمام سرویس‌ها
docker-compose build

# اجرای سرویس‌ها
docker-compose up -d

# مشاهده لاگ‌ها
docker-compose logs -f
```

### گام 4: بررسی وضعیت سرویس‌ها

```bash
docker-compose ps
```

تمام سرویس‌ها باید وضعیت `Up` داشته باشند.

## ⚙️ پیکربندی

### Backend API

فایل: `divar-clone/backend/.env`

```env
DATABASE_HOST=postgres
DATABASE_PORT=5432
DATABASE_USER=postgres
DATABASE_PASSWORD=postgres123
DATABASE_NAME=divar_db

REDIS_HOST=redis
REDIS_PORT=6379

JWT_SECRET=your-secret-key
JWT_EXPIRATION=7d

MINIO_ENDPOINT=minio
MINIO_PORT=9000
MINIO_ACCESS_KEY=minioadmin
MINIO_SECRET_KEY=minioadmin123
```

### Frontend

فایل: `divar-clone/frontend/.env.local`

```env
NEXT_PUBLIC_API_URL=http://localhost:5000/api
NEXT_PUBLIC_WS_URL=ws://localhost:5000
```

### Admin Panel

فایل: `admin-panel/.env.local`

```env
NEXT_PUBLIC_API_BASE_URL=http://localhost:5000/api
ADMIN_USERNAME=admin
ADMIN_PASSWORD=Admin@123456
```

## 🌐 استقرار در محیط Production

### گام 1: آماده‌سازی سرور

```bash
# نصب Docker و Docker Compose
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# نصب Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose
```

### گام 2: پیکربندی Environment Variables

```bash
# کپی و ویرایش فایل .env
cp .env.example .env
nano .env
```

**مهم**: حتماً رمزهای پیش‌فرض را تغییر دهید:

```env
POSTGRES_PASSWORD=very-strong-password-here
REDIS_PASSWORD=another-strong-password
JWT_SECRET=random-secret-key-min-32-characters
MINIO_ROOT_PASSWORD=strong-minio-password
ADMIN_PASSWORD=strong-admin-password

NEXT_PUBLIC_API_URL=https://api.yourdomain.com
NEXT_PUBLIC_WS_URL=wss://api.yourdomain.com
```

### گام 3: راه‌اندازی SSL (اختیاری اما پیشنهادی)

```bash
# نصب Certbot
sudo apt-get update
sudo apt-get install certbot

# دریافت گواهی SSL
sudo certbot certonly --standalone -d yourdomain.com -d www.yourdomain.com -d admin.yourdomain.com

# کپی گواهی‌ها
sudo mkdir -p ./ssl
sudo cp /etc/letsencrypt/live/yourdomain.com/fullchain.pem ./ssl/certificate.crt
sudo cp /etc/letsencrypt/live/yourdomain.com/privkey.pem ./ssl/private.key
```

### گام 4: پیکربندی Nginx

فایل `nginx.conf` را ویرایش کرده و دامنه‌های خود را جایگزین کنید:

```nginx
server_name your-domain.com www.your-domain.com;
```

### گام 5: Deploy

```bash
chmod +x deploy.sh
./deploy.sh
```

یا به صورت دستی:

```bash
docker-compose -f docker-compose.prod.yml build --no-cache
docker-compose -f docker-compose.prod.yml up -d
```

### گام 6: بررسی وضعیت

```bash
# مشاهده وضعیت سرویس‌ها
docker-compose -f docker-compose.prod.yml ps

# مشاهده لاگ‌ها
docker-compose -f docker-compose.prod.yml logs -f
```

## 📚 مستندات API

پس از راه‌اندازی، مستندات کامل API در آدرس زیر قابل دسترسی است:

**Swagger UI**: http://localhost:5000/api/docs

در این مستندات می‌توانید:
- تمام Endpoint های موجود را مشاهده کنید
- Schema های داده را ببینید
- مستقیماً API ها را تست کنید

## 🔧 دستورات مفید

### مشاهده لاگ‌ها

```bash
# تمام سرویس‌ها
docker-compose logs -f

# یک سرویس خاص
docker-compose logs -f backend
docker-compose logs -f frontend
docker-compose logs -f admin
```

### Restart سرویس‌ها

```bash
# تمام سرویس‌ها
docker-compose restart

# یک سرویس خاص
docker-compose restart backend
```

### متوقف کردن سیستم

```bash
# متوقف کردن بدون حذف داده‌ها
docker-compose stop

# متوقف کردن و حذف کانتینرها (داده‌ها حفظ می‌شوند)
docker-compose down

# حذف کامل شامل Volume ها (احتیاط!)
docker-compose down -v
```

### دسترسی به Container

```bash
# دسترسی به Backend
docker-compose exec backend sh

# دسترسی به Database
docker-compose exec postgres psql -U postgres -d divar_db

# دسترسی به Redis
docker-compose exec redis redis-cli
```

### Backup دیتابیس

```bash
# ایجاد Backup
docker-compose exec postgres pg_dump -U postgres divar_db > backup.sql

# Restore از Backup
docker-compose exec -T postgres psql -U postgres divar_db < backup.sql
```

## 🐛 رفع مشکلات

### مشکل: سرویس‌ها Start نمی‌شوند

```bash
# بررسی لاگ‌ها
docker-compose logs

# حذف و ساخت مجدد
docker-compose down
docker-compose build --no-cache
docker-compose up -d
```

### مشکل: پورت در حال استفاده است

```bash
# یافتن پروسس استفاده کننده از پورت
sudo lsof -i :3000
sudo lsof -i :5000

# یا تغییر پورت در docker-compose.yml
ports:
  - "3002:3000"  # به جای 3000:3000
```

### مشکل: Backend به Database متصل نمی‌شود

```bash
# بررسی اینکه PostgreSQL آماده است
docker-compose exec postgres pg_isready

# بررسی اتصال از Backend
docker-compose exec backend ping postgres
```

### مشکل: کمبود فضای دیسک

```bash
# پاک کردن Image های استفاده نشده
docker system prune -a

# پاک کردن Volume های استفاده نشده
docker volume prune
```

### مشکل: Admin Panel لود نمی‌شود

```bash
# بررسی لاگ‌های Admin Panel
docker-compose logs admin

# Rebuild کردن
docker-compose build admin
docker-compose up -d admin
```

## 📊 مانیتورینگ

### بررسی مصرف منابع

```bash
# مشاهده مصرف CPU و RAM
docker stats

# مشاهده فضای استفاده شده
docker system df
```

### Health Check

```bash
# بررسی سلامت سرویس‌ها
docker-compose ps

# تست اتصال به Backend
curl http://localhost:5000/api/health

# تست اتصال به Frontend
curl http://localhost:3000

# تست اتصال به Admin
curl http://localhost:3001
```

## 🔒 امنیت

### توصیه‌های امنیتی برای Production:

1. **تغییر تمام رمزهای پیش‌فرض**
2. **فعال‌سازی HTTPS با SSL**
3. **استفاده از Firewall**
4. **محدود کردن دسترسی به پورت‌ها**
5. **فعال‌سازی Rate Limiting**
6. **Backup منظم از دیتابیس**
7. **به‌روزرسانی منظم Docker Images**

### تنظیم Firewall (UFW)

```bash
# نصب UFW
sudo apt-get install ufw

# اجازه دسترسی به پورت‌های ضروری
sudo ufw allow 22/tcp
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp

# فعال‌سازی Firewall
sudo ufw enable
```

## 📞 پشتیبانی

در صورت بروز هر گونه مشکل:

1. لاگ‌های سیستم را بررسی کنید: `docker-compose logs`
2. مستندات را مطالعه کنید
3. Issue ایجاد کنید در مخزن پروژه

## 📝 لایسنس

این پروژه تحت لایسنس MIT منتشر شده است.

## 👨‍💻 توسعه‌دهنده

**MiniMax Agent** - 2025

---

<div align="center">
  <p>ساخته شده با ❤️ برای جامعه توسعه‌دهندگان ایرانی</p>
</div>

</div>
