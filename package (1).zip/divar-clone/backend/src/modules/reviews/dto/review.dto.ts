import { IsString, IsNumber, Min, Max, IsUUID } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class CreateReviewDto {
  @ApiProperty({ description: 'شناسه آگهی' })
  @IsUUID()
  adId: string;

  @ApiProperty({ description: 'امتیاز', minimum: 1, maximum: 5 })
  @IsNumber()
  @Min(1)
  @Max(5)
  rating: number;

  @ApiProperty({ description: 'متن نظر' })
  @IsString()
  comment: string;
}

export class UpdateReviewDto {
  @ApiProperty({ description: 'امتیاز', minimum: 1, maximum: 5 })
  @IsNumber()
  @Min(1)
  @Max(5)
  rating?: number;

  @ApiProperty({ description: 'متن نظر' })
  @IsString()
  comment?: string;
}
