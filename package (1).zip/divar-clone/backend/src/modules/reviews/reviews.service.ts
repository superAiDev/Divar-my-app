import { Injectable, NotFoundException, ForbiddenException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Review } from '../../database/entities/review.entity';
import { Ad } from '../../database/entities/ad.entity';
import { User } from '../../database/entities/user.entity';
import { CreateReviewDto, UpdateReviewDto } from './dto/review.dto';

@Injectable()
export class ReviewsService {
  constructor(
    @InjectRepository(Review)
    private readonly reviewRepository: Repository<Review>,
    @InjectRepository(Ad)
    private readonly adRepository: Repository<Ad>,
  ) {}

  async create(userId: string, createReviewDto: CreateReviewDto) {
    const ad = await this.adRepository.findOne({
      where: { id: createReviewDto.adId },
    });

    if (!ad) {
      throw new NotFoundException('آگهی یافت نشد');
    }

    const review = this.reviewRepository.create({
      user: { id: userId } as User,
      ad: { id: createReviewDto.adId } as Ad,
      rating: createReviewDto.rating,
      comment: createReviewDto.comment,
    });

    return await this.reviewRepository.save(review);
  }

  async findByAd(adId: string, page: number = 1, limit: number = 20) {
    const [reviews, total] = await this.reviewRepository.findAndCount({
      where: { ad: { id: adId } },
      relations: ['user'],
      skip: (page - 1) * limit,
      take: limit,
      order: { createdAt: 'DESC' },
    });

    const averageRating = await this.getAverageRating(adId);

    return {
      data: reviews,
      meta: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
        averageRating,
      },
    };
  }

  async findByUser(userId: string, page: number = 1, limit: number = 20) {
    const [reviews, total] = await this.reviewRepository.findAndCount({
      where: { user: { id: userId } },
      relations: ['ad'],
      skip: (page - 1) * limit,
      take: limit,
      order: { createdAt: 'DESC' },
    });

    return {
      data: reviews,
      meta: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  async getAverageRating(adId: string): Promise<number> {
    const result = await this.reviewRepository
      .createQueryBuilder('review')
      .select('AVG(review.rating)', 'average')
      .where('review.adId = :adId', { adId })
      .getRawOne();

    return parseFloat(result.average) || 0;
  }

  async update(id: string, userId: string, updateReviewDto: UpdateReviewDto) {
    const review = await this.reviewRepository.findOne({
      where: { id },
      relations: ['user'],
    });

    if (!review) {
      throw new NotFoundException('نظر یافت نشد');
    }

    if (review.user.id !== userId) {
      throw new ForbiddenException('شما مجاز به ویرایش این نظر نیستید');
    }

    Object.assign(review, updateReviewDto);
    return await this.reviewRepository.save(review);
  }

  async delete(id: string, userId: string) {
    const review = await this.reviewRepository.findOne({
      where: { id },
      relations: ['user'],
    });

    if (!review) {
      throw new NotFoundException('نظر یافت نشد');
    }

    if (review.user.id !== userId) {
      throw new ForbiddenException('شما مجاز به حذف این نظر نیستید');
    }

    await this.reviewRepository.remove(review);
    return { message: 'نظر با موفقیت حذف شد' };
  }
}
