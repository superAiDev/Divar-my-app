import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { User } from '../../database/entities/user.entity';
import { UpdateUserDto, ChangePasswordDto } from './dto/update-user.dto';
import * as bcrypt from 'bcryptjs';

@Injectable()
export class UsersService {
  constructor(
    @InjectRepository(User)
    private readonly userRepository: Repository<User>,
  ) {}

  async findAll(page: number = 1, limit: number = 20) {
    const [users, total] = await this.userRepository.findAndCount({
      skip: (page - 1) * limit,
      take: limit,
      order: { createdAt: 'DESC' },
      select: ['id', 'phone', 'name', 'email', 'avatar', 'isVerified', 'createdAt'],
    });

    return {
      data: users,
      meta: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  async findOne(id: string) {
    const user = await this.userRepository.findOne({
      where: { id },
      relations: ['ads', 'favorites', 'reviews'],
    });

    if (!user) {
      throw new NotFoundException('کاربر یافت نشد');
    }

    const { password, ...result } = user;
    return result;
  }

  async findByPhone(phone: string) {
    return await this.userRepository.findOne({ where: { phone } });
  }

  async update(id: string, updateUserDto: UpdateUserDto) {
    const user = await this.findOne(id);
    
    Object.assign(user, updateUserDto);
    await this.userRepository.save(user);

    const { password, ...result } = user;
    return result;
  }

  async changePassword(id: string, changePasswordDto: ChangePasswordDto) {
    const user = await this.userRepository.findOne({ where: { id } });
    
    if (!user) {
      throw new NotFoundException('کاربر یافت نشد');
    }

    const isPasswordValid = await bcrypt.compare(
      changePasswordDto.currentPassword,
      user.password,
    );

    if (!isPasswordValid) {
      throw new BadRequestException('رمز عبور فعلی اشتباه است');
    }

    user.password = await bcrypt.hash(changePasswordDto.newPassword, 10);
    await this.userRepository.save(user);

    return { message: 'رمز عبور با موفقیت تغییر کرد' };
  }

  async getUserStats(id: string) {
    const user = await this.userRepository.findOne({
      where: { id },
      relations: ['ads', 'favorites', 'reviews'],
    });

    if (!user) {
      throw new NotFoundException('کاربر یافت نشد');
    }

    return {
      totalAds: user.ads?.length || 0,
      totalFavorites: user.favorites?.length || 0,
      totalReviews: user.reviews?.length || 0,
      memberSince: user.createdAt,
    };
  }

  async delete(id: string) {
    const result = await this.userRepository.delete(id);
    
    if (result.affected === 0) {
      throw new NotFoundException('کاربر یافت نشد');
    }

    return { message: 'کاربر با موفقیت حذف شد' };
  }
}
