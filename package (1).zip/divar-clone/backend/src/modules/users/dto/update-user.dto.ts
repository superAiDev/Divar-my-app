import { IsString, IsOptional, IsEmail, IsUrl } from 'class-validator';
import { ApiPropertyOptional } from '@nestjs/swagger';

export class UpdateUserDto {
  @ApiPropertyOptional({ description: 'نام کاربر' })
  @IsString()
  @IsOptional()
  name?: string;

  @ApiPropertyOptional({ description: 'ایمیل کاربر' })
  @IsEmail()
  @IsOptional()
  email?: string;

  @ApiPropertyOptional({ description: 'آواتار کاربر' })
  @IsUrl()
  @IsOptional()
  avatar?: string;

  @ApiPropertyOptional({ description: 'بیوگرافی کاربر' })
  @IsString()
  @IsOptional()
  bio?: string;
}

export class ChangePasswordDto {
  @ApiPropertyOptional({ description: 'رمز عبور فعلی' })
  @IsString()
  currentPassword: string;

  @ApiPropertyOptional({ description: 'رمز عبور جدید' })
  @IsString()
  newPassword: string;
}
