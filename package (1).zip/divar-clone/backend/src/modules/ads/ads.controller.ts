import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  Query,
  UseGuards,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth, ApiQuery } from '@nestjs/swagger';
import { AdsService } from './ads.service';
import { CreateAdDto, UpdateAdDto, FilterAdDto } from './dto/ad.dto';
import { JwtAuthGuard, CurrentUser, Roles, RolesGuard } from '../../common';
import { UserRole, AdStatus } from '../../database/entities';

@ApiTags('Ads')
@Controller('ads')
export class AdsController {
  constructor(private readonly adsService: AdsService) {}

  @Post()
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Create a new ad' })
  create(@CurrentUser() user: any, @Body() createAdDto: CreateAdDto) {
    return this.adsService.create(user.id, createAdDto);
  }

  @Get()
  @ApiOperation({ summary: 'Get all ads with filters' })
  findAll(@Query() filterDto: FilterAdDto) {
    return this.adsService.findAll(filterDto);
  }

  @Get('my-ads')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get current user ads' })
  @ApiQuery({ name: 'page', required: false })
  @ApiQuery({ name: 'limit', required: false })
  findMyAds(
    @CurrentUser() user: any,
    @Query('page') page?: number,
    @Query('limit') limit?: number,
  ) {
    return this.adsService.findUserAds(user.id, page, limit);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get ad by ID' })
  findOne(@Param('id') id: string) {
    return this.adsService.findOne(id);
  }

  @Patch(':id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Update ad' })
  update(
    @Param('id') id: string,
    @CurrentUser() user: any,
    @Body() updateAdDto: UpdateAdDto,
  ) {
    return this.adsService.update(id, user.id, updateAdDto);
  }

  @Delete(':id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Delete ad' })
  remove(@Param('id') id: string, @CurrentUser() user: any) {
    return this.adsService.remove(id, user.id);
  }

  @Patch(':id/status')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.ADMIN, UserRole.MODERATOR)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Update ad status (Admin only)' })
  updateStatus(
    @Param('id') id: string,
    @Body('status') status: AdStatus,
  ) {
    return this.adsService.updateStatus(id, status);
  }
}
