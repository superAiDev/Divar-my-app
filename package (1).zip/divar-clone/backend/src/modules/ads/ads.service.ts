import {
  Injectable,
  NotFoundException,
  ForbiddenException,
  BadRequestException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, Like, Between, In } from 'typeorm';
import { Ad, AdStatus, Category, User } from '../../database/entities';
import { CreateAdDto, UpdateAdDto, FilterAdDto } from './dto/ad.dto';

@Injectable()
export class AdsService {
  constructor(
    @InjectRepository(Ad)
    private adRepository: Repository<Ad>,
    @InjectRepository(Category)
    private categoryRepository: Repository<Category>,
  ) {}

  async create(userId: string, createAdDto: CreateAdDto) {
    // Verify category exists
    const category = await this.categoryRepository.findOne({
      where: { id: createAdDto.categoryId },
    });

    if (!category) {
      throw new BadRequestException('Category not found');
    }

    const ad = this.adRepository.create({
      ...createAdDto,
      userId,
      status: AdStatus.PENDING,
    });

    return this.adRepository.save(ad);
  }

  async findAll(filterDto: FilterAdDto) {
    const { categoryId, minPrice, maxPrice, condition, search, page = 1, limit = 20 } = filterDto;

    const query = this.adRepository
      .createQueryBuilder('ad')
      .leftJoinAndSelect('ad.category', 'category')
      .leftJoinAndSelect('ad.user', 'user')
      .leftJoinAndSelect('ad.images', 'images')
      .where('ad.status = :status', { status: AdStatus.ACTIVE })
      .orderBy('ad.createdAt', 'DESC');

    if (categoryId) {
      query.andWhere('ad.categoryId = :categoryId', { categoryId });
    }

    if (minPrice !== undefined) {
      query.andWhere('ad.price >= :minPrice', { minPrice });
    }

    if (maxPrice !== undefined) {
      query.andWhere('ad.price <= :maxPrice', { maxPrice });
    }

    if (condition) {
      query.andWhere('ad.condition = :condition', { condition });
    }

    if (search) {
      query.andWhere(
        '(ad.title ILIKE :search OR ad.description ILIKE :search)',
        { search: `%${search}%` },
      );
    }

    const skip = (page - 1) * limit;
    query.skip(skip).take(limit);

    const [data, total] = await query.getManyAndCount();

    return {
      data,
      meta: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  async findOne(id: string) {
    const ad = await this.adRepository.findOne({
      where: { id },
      relations: ['category', 'user', 'images', 'locations'],
    });

    if (!ad) {
      throw new NotFoundException('Ad not found');
    }

    // Increment view count
    ad.views += 1;
    await this.adRepository.save(ad);

    return ad;
  }

  async findUserAds(userId: string, page = 1, limit = 20) {
    const skip = (page - 1) * limit;

    const [data, total] = await this.adRepository.findAndCount({
      where: { userId },
      relations: ['category', 'images'],
      order: { createdAt: 'DESC' },
      skip,
      take: limit,
    });

    return {
      data,
      meta: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  async update(id: string, userId: string, updateAdDto: UpdateAdDto) {
    const ad = await this.adRepository.findOne({
      where: { id },
      relations: ['user'],
    });

    if (!ad) {
      throw new NotFoundException('Ad not found');
    }

    if (ad.userId !== userId) {
      throw new ForbiddenException('You can only update your own ads');
    }

    if (updateAdDto.categoryId) {
      const category = await this.categoryRepository.findOne({
        where: { id: updateAdDto.categoryId },
      });
      if (!category) {
        throw new BadRequestException('Category not found');
      }
    }

    Object.assign(ad, updateAdDto);
    return this.adRepository.save(ad);
  }

  async remove(id: string, userId: string) {
    const ad = await this.adRepository.findOne({
      where: { id },
    });

    if (!ad) {
      throw new NotFoundException('Ad not found');
    }

    if (ad.userId !== userId) {
      throw new ForbiddenException('You can only delete your own ads');
    }

    await this.adRepository.remove(ad);
    return { message: 'Ad deleted successfully' };
  }

  async updateStatus(id: string, status: AdStatus) {
    const ad = await this.adRepository.findOne({ where: { id } });

    if (!ad) {
      throw new NotFoundException('Ad not found');
    }

    ad.status = status;
    if (status === AdStatus.ACTIVE && !ad.publishedAt) {
      ad.publishedAt = new Date();
    }

    return this.adRepository.save(ad);
  }
}
