import { IsString, IsNumber, IsOptional, IsUUID, IsArray, Min } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class CreateAdDto {
  @ApiProperty({ example: 'فروش خودرو پژو 206' })
  @IsString()
  title: string;

  @ApiProperty({ example: 'توضیحات کامل آگهی...' })
  @IsString()
  description: string;

  @ApiProperty({ example: 250000000 })
  @IsNumber()
  @Min(0)
  @IsOptional()
  price?: number;

  @ApiProperty()
  @IsUUID()
  categoryId: string;

  @ApiProperty({ example: 'تهران' })
  @IsString()
  city: string;

  @ApiProperty({ example: 'ونک' })
  @IsString()
  @IsOptional()
  neighborhood?: string;

  @ApiProperty({ type: [String] })
  @IsArray()
  @IsOptional()
  images?: string[];

  @ApiProperty({ type: Object })
  @IsOptional()
  attributes?: any;
}
