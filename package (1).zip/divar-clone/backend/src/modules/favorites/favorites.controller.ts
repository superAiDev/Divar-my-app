import {
  Controller,
  Get,
  Post,
  Delete,
  Body,
  Param,
  Query,
  UseGuards,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { FavoritesService } from './favorites.service';
import { CreateFavoriteDto } from './dto/create-favorite.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { User } from '../../database/entities/user.entity';

@ApiTags('Favorites')
@Controller('favorites')
@UseGuards(JwtAuthGuard)
@ApiBearerAuth()
export class FavoritesController {
  constructor(private readonly favoritesService: FavoritesService) {}

  @Post()
  @ApiOperation({ summary: 'افزودن آگهی به علاقه‌مندی‌ها' })
  async create(
    @CurrentUser() user: User,
    @Body() createFavoriteDto: CreateFavoriteDto,
  ) {
    return await this.favoritesService.create(user.id, createFavoriteDto);
  }

  @Get()
  @ApiOperation({ summary: 'دریافت لیست علاقه‌مندی‌ها' })
  async findAll(
    @CurrentUser() user: User,
    @Query('page') page: number = 1,
    @Query('limit') limit: number = 20,
  ) {
    return await this.favoritesService.findAll(user.id, page, limit);
  }

  @Get('check/:adId')
  @ApiOperation({ summary: 'بررسی وجود آگهی در علاقه‌مندی‌ها' })
  async isFavorite(
    @CurrentUser() user: User,
    @Param('adId') adId: string,
  ) {
    const isFavorite = await this.favoritesService.isFavorite(user.id, adId);
    return { isFavorite };
  }

  @Delete(':adId')
  @ApiOperation({ summary: 'حذف آگهی از علاقه‌مندی‌ها' })
  async remove(
    @CurrentUser() user: User,
    @Param('adId') adId: string,
  ) {
    return await this.favoritesService.remove(user.id, adId);
  }
}
