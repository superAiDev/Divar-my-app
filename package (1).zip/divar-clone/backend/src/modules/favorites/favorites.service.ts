import { Injectable, NotFoundException, ConflictException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Favorite } from '../../database/entities/favorite.entity';
import { Ad } from '../../database/entities/ad.entity';
import { User } from '../../database/entities/user.entity';
import { CreateFavoriteDto } from './dto/create-favorite.dto';

@Injectable()
export class FavoritesService {
  constructor(
    @InjectRepository(Favorite)
    private readonly favoriteRepository: Repository<Favorite>,
    @InjectRepository(Ad)
    private readonly adRepository: Repository<Ad>,
  ) {}

  async create(userId: string, createFavoriteDto: CreateFavoriteDto) {
    const ad = await this.adRepository.findOne({
      where: { id: createFavoriteDto.adId },
    });

    if (!ad) {
      throw new NotFoundException('آگهی یافت نشد');
    }

    const existingFavorite = await this.favoriteRepository.findOne({
      where: {
        user: { id: userId },
        ad: { id: createFavoriteDto.adId },
      },
    });

    if (existingFavorite) {
      throw new ConflictException('این آگهی قبلاً به علاقه‌مندی‌ها اضافه شده است');
    }

    const favorite = this.favoriteRepository.create({
      user: { id: userId } as User,
      ad: { id: createFavoriteDto.adId } as Ad,
    });

    return await this.favoriteRepository.save(favorite);
  }

  async findAll(userId: string, page: number = 1, limit: number = 20) {
    const [favorites, total] = await this.favoriteRepository.findAndCount({
      where: { user: { id: userId } },
      relations: ['ad', 'ad.images', 'ad.category', 'ad.location'],
      skip: (page - 1) * limit,
      take: limit,
      order: { createdAt: 'DESC' },
    });

    return {
      data: favorites,
      meta: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  async remove(userId: string, adId: string) {
    const favorite = await this.favoriteRepository.findOne({
      where: {
        user: { id: userId },
        ad: { id: adId },
      },
    });

    if (!favorite) {
      throw new NotFoundException('این آگهی در علاقه‌مندی‌های شما یافت نشد');
    }

    await this.favoriteRepository.remove(favorite);
    return { message: 'آگهی از علاقه‌مندی‌ها حذف شد' };
  }

  async isFavorite(userId: string, adId: string): Promise<boolean> {
    const favorite = await this.favoriteRepository.findOne({
      where: {
        user: { id: userId },
        ad: { id: adId },
      },
    });

    return !!favorite;
  }
}
