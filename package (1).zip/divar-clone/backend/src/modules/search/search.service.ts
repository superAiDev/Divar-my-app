import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Ad } from '../../database/entities/ad.entity';

@Injectable()
export class SearchService {
  constructor(
    @InjectRepository(Ad)
    private adRepository: Repository<Ad>,
  ) {}

  async search(query: string, filters: any) {
    // TODO: Integrate with Elasticsearch
    // For now, using basic SQL search
    
    const queryBuilder = this.adRepository
      .createQueryBuilder('ad')
      .leftJoinAndSelect('ad.category', 'category')
      .leftJoinAndSelect('ad.user', 'user')
      .where('ad.status = :status', { status: 'active' });

    if (query) {
      queryBuilder.andWhere(
        '(ad.title LIKE :query OR ad.description LIKE :query)',
        { query: `%${query}%` }
      );
    }

    if (filters.category) {
      queryBuilder.andWhere('ad.categoryId = :categoryId', {
        categoryId: filters.category,
      });
    }

    if (filters.city) {
      queryBuilder.andWhere('ad.city = :city', { city: filters.city });
    }

    if (filters.minPrice) {
      queryBuilder.andWhere('ad.price >= :minPrice', {
        minPrice: filters.minPrice,
      });
    }

    if (filters.maxPrice) {
      queryBuilder.andWhere('ad.price <= :maxPrice', {
        maxPrice: filters.maxPrice,
      });
    }

    return queryBuilder
      .orderBy('ad.createdAt', 'DESC')
      .limit(filters.limit || 20)
      .getMany();
  }

  async autocomplete(query: string) {
    const results = await this.adRepository
      .createQueryBuilder('ad')
      .select(['ad.title'])
      .where('ad.title LIKE :query', { query: `%${query}%` })
      .andWhere('ad.status = :status', { status: 'active' })
      .limit(10)
      .getMany();

    return results.map(ad => ad.title);
  }
}
