import { Controller, Get, Query } from '@nestjs/common';
import { ApiTags, ApiOperation } from '@nestjs/swagger';
import { SearchService } from './search.service';

@ApiTags('Search')
@Controller('search')
export class SearchController {
  constructor(private readonly searchService: SearchService) {}

  @Get()
  @ApiOperation({ summary: 'جستجوی پیشرفته' })
  search(@Query() query: any) {
    return this.searchService.search(query.q, query);
  }

  @Get('autocomplete')
  @ApiOperation({ summary: 'پیشنهاد خودکار' })
  autocomplete(@Query('q') query: string) {
    return this.searchService.autocomplete(query);
  }
}
