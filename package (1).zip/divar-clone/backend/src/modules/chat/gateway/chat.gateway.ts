import {
  WebSocketGateway,
  WebSocketServer,
  SubscribeMessage,
  OnGatewayConnection,
  OnGatewayDisconnect,
  ConnectedSocket,
  MessageBody,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { UseGuards } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { ChatService } from '../chat.service';

interface AuthenticatedSocket extends Socket {
  user?: any;
}

@WebSocketGateway({
  cors: {
    origin: '*',
  },
  namespace: '/chat',
})
export class ChatGateway implements OnGatewayConnection, OnGatewayDisconnect {
  @WebSocketServer()
  server: Server;

  private connectedUsers = new Map<string, string>();

  constructor(
    private chatService: ChatService,
    private jwtService: JwtService,
  ) {}

  async handleConnection(client: AuthenticatedSocket) {
    try {
      const token = client.handshake.auth.token || client.handshake.headers.authorization?.split(' ')[1];

      if (!token) {
        client.disconnect();
        return;
      }

      const payload = this.jwtService.verify(token);
      client.user = payload;

      this.connectedUsers.set(payload.sub, client.id);
      console.log(`✅ User ${payload.sub} connected to chat`);

      // Join user to their personal room
      client.join(`user:${payload.sub}`);

      // Notify online status
      client.broadcast.emit('user:online', { userId: payload.sub });
    } catch (error) {
      console.error('WebSocket auth error:', error.message);
      client.disconnect();
    }
  }

  handleDisconnect(client: AuthenticatedSocket) {
    if (client.user) {
      this.connectedUsers.delete(client.user.sub);
      console.log(`❌ User ${client.user.sub} disconnected from chat`);

      // Notify offline status
      client.broadcast.emit('user:offline', { userId: client.user.sub });
    }
  }

  @SubscribeMessage('message:send')
  async handleMessage(
    @ConnectedSocket() client: AuthenticatedSocket,
    @MessageBody() data: { conversationId: string; content: string; attachmentUrl?: string },
  ) {
    try {
      const message = await this.chatService.sendMessage(client.user.sub, {
        conversationId: data.conversationId,
        content: data.content,
        attachmentUrl: data.attachmentUrl,
      });

      // Get conversation to find the recipient
      const conversations = await this.chatService.getUserConversations(client.user.sub);
      const conversation = conversations.find(c => c.id === data.conversationId);

      if (conversation) {
        const recipientId = conversation.user1Id === client.user.sub 
          ? conversation.user2Id 
          : conversation.user1Id;

        // Emit to recipient
        this.server.to(`user:${recipientId}`).emit('message:new', message);
      }

      // Emit back to sender
      client.emit('message:sent', message);

      return message;
    } catch (error) {
      client.emit('message:error', { error: error.message });
    }
  }

  @SubscribeMessage('typing:start')
  handleTypingStart(
    @ConnectedSocket() client: AuthenticatedSocket,
    @MessageBody() data: { conversationId: string; recipientId: string },
  ) {
    this.server.to(`user:${data.recipientId}`).emit('typing:start', {
      conversationId: data.conversationId,
      userId: client.user.sub,
    });
  }

  @SubscribeMessage('typing:stop')
  handleTypingStop(
    @ConnectedSocket() client: AuthenticatedSocket,
    @MessageBody() data: { conversationId: string; recipientId: string },
  ) {
    this.server.to(`user:${data.recipientId}`).emit('typing:stop', {
      conversationId: data.conversationId,
      userId: client.user.sub,
    });
  }

  @SubscribeMessage('conversation:join')
  handleJoinConversation(
    @ConnectedSocket() client: AuthenticatedSocket,
    @MessageBody() data: { conversationId: string },
  ) {
    client.join(`conversation:${data.conversationId}`);
  }

  @SubscribeMessage('conversation:leave')
  handleLeaveConversation(
    @ConnectedSocket() client: AuthenticatedSocket,
    @MessageBody() data: { conversationId: string },
  ) {
    client.leave(`conversation:${data.conversationId}`);
  }
}
