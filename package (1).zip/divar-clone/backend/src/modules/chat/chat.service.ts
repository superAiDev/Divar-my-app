import { Injectable, NotFoundException, ForbiddenException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, In } from 'typeorm';
import { Conversation, Message, User } from '../../database/entities';
import { CreateConversationDto, SendMessageDto } from './dto/chat.dto';

@Injectable()
export class ChatService {
  constructor(
    @InjectRepository(Conversation)
    private conversationRepository: Repository<Conversation>,
    @InjectRepository(Message)
    private messageRepository: Repository<Message>,
    @InjectRepository(User)
    private userRepository: Repository<User>,
  ) {}

  async createConversation(userId: string, dto: CreateConversationDto) {
    const { recipientId } = dto;

    if (userId === recipientId) {
      throw new ForbiddenException('Cannot create conversation with yourself');
    }

    // Check if conversation already exists
    const existing = await this.conversationRepository
      .createQueryBuilder('conversation')
      .where(
        '(conversation.user1Id = :userId AND conversation.user2Id = :recipientId) OR (conversation.user1Id = :recipientId AND conversation.user2Id = :userId)',
        { userId, recipientId },
      )
      .getOne();

    if (existing) {
      return existing;
    }

    // Verify recipient exists
    const recipient = await this.userRepository.findOne({ where: { id: recipientId } });
    if (!recipient) {
      throw new NotFoundException('Recipient not found');
    }

    const conversation = this.conversationRepository.create({
      user1Id: userId,
      user2Id: recipientId,
    });

    return this.conversationRepository.save(conversation);
  }

  async getUserConversations(userId: string) {
    const conversations = await this.conversationRepository
      .createQueryBuilder('conversation')
      .leftJoinAndSelect('conversation.user1', 'user1')
      .leftJoinAndSelect('conversation.user2', 'user2')
      .where('conversation.user1Id = :userId OR conversation.user2Id = :userId', { userId })
      .orderBy('conversation.lastMessageAt', 'DESC', 'NULLS LAST')
      .addOrderBy('conversation.createdAt', 'DESC')
      .getMany();

    return conversations.map(conv => ({
      ...conv,
      otherUser: conv.user1Id === userId ? conv.user2 : conv.user1,
    }));
  }

  async sendMessage(userId: string, dto: SendMessageDto) {
    const { conversationId, content, attachmentUrl } = dto;

    const conversation = await this.conversationRepository.findOne({
      where: { id: conversationId },
    });

    if (!conversation) {
      throw new NotFoundException('Conversation not found');
    }

    // Verify user is part of the conversation
    if (conversation.user1Id !== userId && conversation.user2Id !== userId) {
      throw new ForbiddenException('You are not part of this conversation');
    }

    const message = this.messageRepository.create({
      conversationId,
      senderId: userId,
      content,
      attachmentUrl,
    });

    const savedMessage = await this.messageRepository.save(message);

    // Update conversation's last message
    conversation.lastMessageAt = new Date();
    conversation.lastMessageText = content.substring(0, 100);
    await this.conversationRepository.save(conversation);

    // Load sender info
    const fullMessage = await this.messageRepository.findOne({
      where: { id: savedMessage.id },
      relations: ['sender'],
    });

    return fullMessage;
  }

  async getConversationMessages(
    userId: string,
    conversationId: string,
    page = 1,
    limit = 50,
  ) {
    const conversation = await this.conversationRepository.findOne({
      where: { id: conversationId },
    });

    if (!conversation) {
      throw new NotFoundException('Conversation not found');
    }

    if (conversation.user1Id !== userId && conversation.user2Id !== userId) {
      throw new ForbiddenException('You are not part of this conversation');
    }

    const skip = (page - 1) * limit;

    const [messages, total] = await this.messageRepository.findAndCount({
      where: { conversationId },
      relations: ['sender'],
      order: { createdAt: 'DESC' },
      skip,
      take: limit,
    });

    return {
      data: messages.reverse(),
      meta: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  async markAsRead(userId: string, conversationId: string) {
    const conversation = await this.conversationRepository.findOne({
      where: { id: conversationId },
    });

    if (!conversation) {
      throw new NotFoundException('Conversation not found');
    }

    if (conversation.user1Id !== userId && conversation.user2Id !== userId) {
      throw new ForbiddenException('You are not part of this conversation');
    }

    // Mark all messages in this conversation (not sent by user) as read
    await this.messageRepository
      .createQueryBuilder()
      .update(Message)
      .set({ isRead: true, readAt: new Date() })
      .where('conversationId = :conversationId', { conversationId })
      .andWhere('senderId != :userId', { userId })
      .andWhere('isRead = :isRead', { isRead: false })
      .execute();

    return { message: 'Messages marked as read' };
  }
}
