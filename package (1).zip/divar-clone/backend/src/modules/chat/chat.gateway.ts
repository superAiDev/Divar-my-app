import {
  WebSocketGateway,
  WebSocketServer,
  SubscribeMessage,
  OnGatewayConnection,
  OnGatewayDisconnect,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { Injectable } from '@nestjs/common';

@WebSocketGateway({
  cors: {
    origin: '*',
  },
})
@Injectable()
export class ChatGateway implements OnGatewayConnection, OnGatewayDisconnect {
  @WebSocketServer()
  server: Server;

  private connectedUsers = new Map<string, string>();

  handleConnection(client: Socket) {
    console.log(`Client connected: ${client.id}`);
  }

  handleDisconnect(client: Socket) {
    console.log(`Client disconnected: ${client.id}`);
    this.connectedUsers.delete(client.id);
  }

  @SubscribeMessage('joinRoom')
  handleJoinRoom(client: Socket, room: string) {
    client.join(room);
    return { event: 'joinedRoom', data: room };
  }

  @SubscribeMessage('sendMessage')
  handleMessage(client: Socket, payload: any) {
    this.server.to(payload.room).emit('newMessage', {
      userId: payload.userId,
      message: payload.message,
      timestamp: new Date(),
    });
  }

  @SubscribeMessage('typing')
  handleTyping(client: Socket, payload: any) {
    client.to(payload.room).emit('userTyping', {
      userId: payload.userId,
      isTyping: payload.isTyping,
    });
  }
}
