import { Injectable, Logger, OnModuleInit } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as Minio from 'minio';
import { v4 as uuidv4 } from 'uuid';
import * as sharp from 'sharp';

@Injectable()
export class StorageService implements OnModuleInit {
  private readonly logger = new Logger(StorageService.name);
  private minioClient: Minio.Client;
  private bucketName: string;

  constructor(private configService: ConfigService) {
    this.bucketName =
      this.configService.get('MINIO_BUCKET') || 'divar-uploads';

    this.minioClient = new Minio.Client({
      endPoint: this.configService.get('MINIO_ENDPOINT', 'localhost'),
      port: parseInt(this.configService.get('MINIO_PORT', '9000')),
      useSSL: this.configService.get('MINIO_USE_SSL') === 'true',
      accessKey: this.configService.get('MINIO_ACCESS_KEY', 'minioadmin'),
      secretKey: this.configService.get('MINIO_SECRET_KEY', 'minioadmin'),
    });
  }

  async onModuleInit() {
    // Create bucket if not exists
    try {
      const exists = await this.minioClient.bucketExists(this.bucketName);
      if (!exists) {
        await this.minioClient.makeBucket(this.bucketName, 'us-east-1');
        this.logger.log(`Bucket ${this.bucketName} created`);
      }

      // Set public policy
      const policy = {
        Version: '2012-10-17',
        Statement: [
          {
            Effect: 'Allow',
            Principal: { AWS: ['*'] },
            Action: ['s3:GetObject'],
            Resource: [`arn:aws:s3:::${this.bucketName}/*`],
          },
        ],
      };
      await this.minioClient.setBucketPolicy(
        this.bucketName,
        JSON.stringify(policy),
      );
    } catch (error) {
      this.logger.error('MinIO initialization error:', error.message);
    }
  }

  async uploadImage(
    file: Express.Multer.File,
    folder: string = 'ads',
  ): Promise<{
    original: string;
    thumbnail: string;
    medium: string;
    large: string;
  }> {
    const fileId = uuidv4();
    const ext = file.originalname.split('.').pop();

    // Generate different sizes
    const original = await this.uploadFile(
      file.buffer,
      `${folder}/${fileId}_original.${ext}`,
    );

    const thumbnail = await this.uploadResizedImage(
      file.buffer,
      `${folder}/${fileId}_thumbnail.${ext}`,
      200,
      200,
    );

    const medium = await this.uploadResizedImage(
      file.buffer,
      `${folder}/${fileId}_medium.${ext}`,
      600,
      600,
    );

    const large = await this.uploadResizedImage(
      file.buffer,
      `${folder}/${fileId}_large.${ext}`,
      1200,
      1200,
    );

    return {
      original,
      thumbnail,
      medium,
      large,
    };
  }

  private async uploadFile(
    buffer: Buffer,
    objectName: string,
  ): Promise<string> {
    await this.minioClient.putObject(this.bucketName, objectName, buffer);
    return this.getFileUrl(objectName);
  }

  private async uploadResizedImage(
    buffer: Buffer,
    objectName: string,
    width: number,
    height: number,
  ): Promise<string> {
    try {
      const resized = await sharp(buffer)
        .resize(width, height, {
          fit: 'inside',
          withoutEnlargement: true,
        })
        .jpeg({ quality: 85 })
        .toBuffer();

      return await this.uploadFile(resized, objectName);
    } catch (error) {
      this.logger.error('Image resize error:', error.message);
      // Fallback to original
      return await this.uploadFile(buffer, objectName);
    }
  }

  private getFileUrl(objectName: string): string {
    const endpoint = this.configService.get('MINIO_ENDPOINT', 'localhost');
    const port = this.configService.get('MINIO_PORT', '9000');
    const useSSL = this.configService.get('MINIO_USE_SSL') === 'true';
    const protocol = useSSL ? 'https' : 'http';

    return `${protocol}://${endpoint}:${port}/${this.bucketName}/${objectName}`;
  }

  async deleteFile(url: string): Promise<void> {
    try {
      const objectName = url.split(`/${this.bucketName}/`)[1];
      if (objectName) {
        await this.minioClient.removeObject(this.bucketName, objectName);
      }
    } catch (error) {
      this.logger.error('File delete error:', error.message);
    }
  }
}
