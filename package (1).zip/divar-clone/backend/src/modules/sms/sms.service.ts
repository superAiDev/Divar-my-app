import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import axios from 'axios';

@Injectable()
export class SmsService {
  private readonly logger = new Logger(SmsService.name);
  private readonly provider: string;

  constructor(private configService: ConfigService) {
    this.provider = this.configService.get('SMS_PROVIDER', 'kavenegar');
  }

  async sendOtp(phoneNumber: string, otp: string): Promise<void> {
    // In development, just log the OTP
    if (this.configService.get('NODE_ENV') === 'development') {
      this.logger.log(`OTP for ${phoneNumber}: ${otp}`);
      return;
    }

    switch (this.provider) {
      case 'kavenegar':
        await this.sendViaKavenegar(phoneNumber, otp);
        break;
      case 'ghasedak':
        await this.sendViaGhasedak(phoneNumber, otp);
        break;
      default:
        this.logger.warn('No SMS provider configured');
    }
  }

  private async sendViaKavenegar(
    phoneNumber: string,
    otp: string,
  ): Promise<void> {
    const apiKey = this.configService.get('KAVENEGAR_API_KEY');
    const sender = this.configService.get('KAVENEGAR_SENDER');
    const template = this.configService.get('KAVENEGAR_TEMPLATE', 'verify');

    try {
      await axios.get(
        `https://api.kavenegar.com/v1/${apiKey}/verify/lookup.json`,
        {
          params: {
            receptor: phoneNumber,
            token: otp,
            template: template,
          },
        },
      );
      this.logger.log(`OTP sent via Kavenegar to ${phoneNumber}`);
    } catch (error) {
      this.logger.error('Kavenegar error:', error.message);
      throw new Error('Failed to send OTP');
    }
  }

  private async sendViaGhasedak(
    phoneNumber: string,
    otp: string,
  ): Promise<void> {
    const apiKey = this.configService.get('GHASEDAK_API_KEY');

    try {
      await axios.post(
        'https://api.ghasedak.me/v2/verification/send/simple',
        {
          receptor: phoneNumber,
          type: '1',
          template: 'verify',
          param1: otp,
        },
        {
          headers: {
            apikey: apiKey,
            'Content-Type': 'application/json',
          },
        },
      );
      this.logger.log(`OTP sent via Ghasedak to ${phoneNumber}`);
    } catch (error) {
      this.logger.error('Ghasedak error:', error.message);
      throw new Error('Failed to send OTP');
    }
  }

  async send(phoneNumber: string, message: string): Promise<void> {
    // Generic SMS sending (for notifications)
    if (this.configService.get('NODE_ENV') === 'development') {
      this.logger.log(`SMS to ${phoneNumber}: ${message}`);
      return;
    }

    // Implement based on provider
    this.logger.log(`Sending SMS to ${phoneNumber}`);
  }
}
