import { Injectable, OnModuleDestroy } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import Redis from 'ioredis';

@Injectable()
export class RedisService extends Redis implements OnModuleDestroy {
  constructor(private configService: ConfigService) {
    super({
      host: configService.get('REDIS_HOST', 'localhost'),
      port: configService.get('REDIS_PORT', 6379),
      password: configService.get('REDIS_PASSWORD'),
      retryStrategy: (times) => {
        const delay = Math.min(times * 50, 2000);
        return delay;
      },
    });
  }

  async onModuleDestroy() {
    await this.quit();
  }

  async setex(key: string, seconds: number, value: string): Promise<string> {
    return super.setex(key, seconds, value);
  }

  async get(key: string): Promise<string | null> {
    return super.get(key);
  }

  async del(...keys: string[]): Promise<number> {
    return super.del(...keys);
  }

  async incr(key: string): Promise<number> {
    return super.incr(key);
  }

  async expire(key: string, seconds: number): Promise<number> {
    return super.expire(key, seconds);
  }

  async sadd(key: string, ...members: string[]): Promise<number> {
    return super.sadd(key, ...members);
  }

  async srem(key: string, ...members: string[]): Promise<number> {
    return super.srem(key, ...members);
  }

  async sismember(key: string, member: string): Promise<boolean> {
    const result = await super.sismember(key, member);
    return result === 1;
  }
}
