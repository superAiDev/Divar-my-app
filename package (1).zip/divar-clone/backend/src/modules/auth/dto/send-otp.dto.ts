import { IsPhoneNumber, IsNotEmpty } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class SendOtpDto {
  @ApiProperty({ example: '09123456789', description: 'شماره موبایل کاربر' })
  @IsPhoneNumber('IR')
  @IsNotEmpty()
  phoneNumber: string;
}
