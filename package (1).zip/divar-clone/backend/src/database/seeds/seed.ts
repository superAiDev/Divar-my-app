import { DataSource } from 'typeorm';
import dataSource from '../data-source';
import { User, UserRole } from '../entities/user.entity';
import { Category } from '../entities/category.entity';
import { Ad, AdStatus } from '../entities/ad.entity';
import * as bcrypt from 'bcrypt';

async function seed() {
  console.log('🌱 Starting database seeding...');

  try {
    await dataSource.initialize();
    console.log('✅ Database connection established');

    const userRepo = dataSource.getRepository(User);
    const categoryRepo = dataSource.getRepository(Category);
    const adRepo = dataSource.getRepository(Ad);

    // Clear existing data
    console.log('🧹 Clearing existing data...');
    await adRepo.delete({});
    await categoryRepo.delete({});
    await userRepo.delete({});

    // Create users
    console.log('👥 Creating users...');
    const users = await userRepo.save([
      {
        phone: '09123456789',
        name: 'علی محمدی',
        email: 'ali@example.com',
        role: UserRole.ADMIN,
        isVerified: true,
        isActive: true,
      },
      {
        phone: '09124567890',
        name: 'سارا احمدی',
        email: 'sara@example.com',
        role: UserRole.USER,
        isVerified: true,
        isActive: true,
      },
      {
        phone: '09125678901',
        name: 'حسین کریمی',
        email: 'hossein@example.com',
        role: UserRole.USER,
        isVerified: true,
        isActive: true,
      },
    ]);
    console.log(`✅ Created ${users.length} users`);

    // Create categories
    console.log('📁 Creating categories...');
    const categories = [
      {
        name: 'وسایل الکترونیک',
        slug: 'electronics',
        icon: '📱',
        order: 1,
        children: [
          { name: 'موبایل', slug: 'mobile', icon: '📱', order: 1 },
          { name: 'لپتاپ', slug: 'laptop', icon: '💻', order: 2 },
          { name: 'تبلت', slug: 'tablet', icon: '📲', order: 3 },
        ],
      },
      {
        name: 'خودرو',
        slug: 'vehicles',
        icon: '🚗',
        order: 2,
        children: [
          { name: 'سواری', slug: 'car', icon: '🚗', order: 1 },
          { name: 'موتورسیکلت', slug: 'motorcycle', icon: '🏍️', order: 2 },
        ],
      },
      {
        name: 'املاک',
        slug: 'real-estate',
        icon: '🏠',
        order: 3,
        children: [
          { name: 'فروش آپارتمان', slug: 'apartment-sale', icon: '🏢', order: 1 },
          { name: 'اجاره آپارتمان', slug: 'apartment-rent', icon: '🏘️', order: 2 },
        ],
      },
      {
        name: 'لوازم خانه و آشپزخانه',
        slug: 'home-kitchen',
        icon: '🛋️',
        order: 4,
      },
      {
        name: 'خدمات',
        slug: 'services',
        icon: '🔧',
        order: 5,
      },
      {
        name: 'لباس و پوشاک',
        slug: 'clothing',
        icon: '👔',
        order: 6,
      },
    ];

    const savedCategories = [];
    for (const catData of categories) {
      const { children, ...parentData } = catData as any;
      const parent = await categoryRepo.save(parentData);
      savedCategories.push(parent);

      if (children) {
        for (const childData of children) {
          const child = await categoryRepo.save({
            ...childData,
            parentId: parent.id,
          });
          savedCategories.push(child);
        }
      }
    }
    console.log(`✅ Created ${savedCategories.length} categories`);

    // Create sample ads
    console.log('📢 Creating sample ads...');
    const electronics = savedCategories.find(c => c.slug === 'mobile');
    const vehicles = savedCategories.find(c => c.slug === 'car');
    const realEstate = savedCategories.find(c => c.slug === 'apartment-sale');

    const ads = await adRepo.save([
      {
        title: 'iPhone 15 Pro Max 256GB - آکبند',
        description: 'گوشی در حد نو، بدون خط و خش، همراه با کارتن و لوازم جانبی',
        price: 45000000,
        isNegotiable: true,
        status: AdStatus.ACTIVE,
        userId: users[0].id,
        categoryId: electronics.id,
        publishedAt: new Date(),
      },
      {
        title: 'سمند مدل 1400 - صفر کیلومتر',
        description: 'خودروی کاملا سالم و بدون رنگ، مدارک کامل',
        price: 380000000,
        isNegotiable: true,
        status: AdStatus.ACTIVE,
        userId: users[1].id,
        categoryId: vehicles.id,
        publishedAt: new Date(),
      },
      {
        title: 'آپارتمان 120 متری - تهران، ولنجک',
        description: '3 خواب، طبقه 5، نوساز، فول امکانات',
        price: 12000000000,
        isNegotiable: true,
        status: AdStatus.ACTIVE,
        userId: users[2].id,
        categoryId: realEstate.id,
        publishedAt: new Date(),
      },
      {
        title: 'لپتاپ MacBook Pro M2 - استفاده شده',
        description: '16GB RAM, 512GB SSD, نگهداری شده',
        price: 55000000,
        isNegotiable: false,
        status: AdStatus.ACTIVE,
        userId: users[0].id,
        categoryId: savedCategories.find(c => c.slug === 'laptop').id,
        publishedAt: new Date(),
      },
    ]);
    console.log(`✅ Created ${ads.length} ads`);

    console.log('\n🎉 Seeding completed successfully!');
    console.log('\n📊 Summary:');
    console.log(`   Users: ${users.length}`);
    console.log(`   Categories: ${savedCategories.length}`);
    console.log(`   Ads: ${ads.length}`);
    console.log('\n🔐 Test User:');
    console.log('   Phone: 09123456789');
    console.log('   Role: ADMIN');
    console.log('\n');

    await dataSource.destroy();
  } catch (error) {
    console.error('❌ Error during seeding:', error);
    throw error;
  }
}

seed();
