import { DataSource } from 'typeorm';
import { runSeeds } from './seeds/seed';
import * as dotenv from 'dotenv';

dotenv.config();

const AppDataSource = new DataSource({
  type: 'postgres',
  host: process.env.DATABASE_HOST || 'localhost',
  port: parseInt(process.env.DATABASE_PORT || '5432'),
  username: process.env.DATABASE_USER || 'postgres',
  password: process.env.DATABASE_PASSWORD || 'postgres123',
  database: process.env.DATABASE_NAME || 'divar_db',
  entities: ['src/database/entities/*.entity.ts'],
  synchronize: true,
});

async function main() {
  try {
    await AppDataSource.initialize();
    console.log('✅ Database connected');
    
    await runSeeds(AppDataSource);
    
    await AppDataSource.destroy();
    console.log('✅ Database connection closed');
    process.exit(0);
  } catch (error) {
    console.error('❌ Seeding error:', error);
    process.exit(1);
  }
}

main();
