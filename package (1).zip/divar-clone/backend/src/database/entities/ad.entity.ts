import {
  Entity,
  Column,
  PrimaryGeneratedColumn,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  OneToMany,
  JoinColumn,
  Index,
} from 'typeorm';
import { User } from './user.entity';
import { Category } from './category.entity';
import { AdImage } from './ad-image.entity';
import { Favorite } from './favorite.entity';
import { Location } from './location.entity';

export enum AdStatus {
  DRAFT = 'draft',
  PENDING = 'pending',
  ACTIVE = 'active',
  SOLD = 'sold',
  EXPIRED = 'expired',
  REJECTED = 'rejected',
}

export enum AdCondition {
  NEW = 'new',
  LIKE_NEW = 'like_new',
  GOOD = 'good',
  FAIR = 'fair',
}

@Entity('ads')
@Index(['status', 'createdAt'])
@Index(['categoryId', 'status'])
export class Ad {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  @Index()
  title: string;

  @Column('text')
  description: string;

  @Column({ type: 'decimal', precision: 12, scale: 2 })
  price: number;

  @Column({ default: true })
  isNegotiable: boolean;

  @Column({ type: 'enum', enum: AdCondition, nullable: true })
  condition: AdCondition;

  @Column({ type: 'enum', enum: AdStatus, default: AdStatus.DRAFT })
  @Index()
  status: AdStatus;

  @Column({ default: 0 })
  views: number;

  @Column({ nullable: true })
  expiresAt: Date;

  @Column({ nullable: true })
  publishedAt: Date;

  @Column('simple-json', { nullable: true })
  customFields: Record<string, any>;

  @Column()
  userId: string;

  @ManyToOne(() => User, (user) => user.ads, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'userId' })
  user: User;

  @Column()
  categoryId: string;

  @ManyToOne(() => Category, (category) => category.ads)
  @JoinColumn({ name: 'categoryId' })
  category: Category;

  @OneToMany(() => AdImage, (image) => image.ad, { cascade: true })
  images: AdImage[];

  @OneToMany(() => Favorite, (favorite) => favorite.ad)
  favorites: Favorite[];

  @OneToMany(() => Location, (location) => location.ad)
  locations: Location[];

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}
