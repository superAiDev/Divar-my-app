import {
  Entity,
  Column,
  PrimaryGeneratedColumn,
  CreateDateColumn,
  ManyToOne,
  JoinColumn,
  Index,
} from 'typeorm';
import { User } from './user.entity';

@Entity('reviews')
@Index(['reviewerId', 'revieweeId'])
export class Review {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'int' })
  rating: number;

  @Column('text', { nullable: true })
  comment: string;

  @Column()
  reviewerId: string;

  @Column()
  revieweeId: string;

  @ManyToOne(() => User, (user) => user.reviewsGiven, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'reviewerId' })
  reviewer: User;

  @ManyToOne(() => User, (user) => user.reviewsReceived, {
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'revieweeId' })
  reviewee: User;

  @CreateDateColumn()
  createdAt: Date;
}
