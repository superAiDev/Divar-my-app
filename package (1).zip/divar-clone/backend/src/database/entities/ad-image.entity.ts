import {
  Entity,
  Column,
  PrimaryGeneratedColumn,
  CreateDateColumn,
  ManyToOne,
  JoinColumn,
} from 'typeorm';
import { Ad } from './ad.entity';

@Entity('ad_images')
export class AdImage {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  url: string;

  @Column({ nullable: true })
  thumbnail: string;

  @Column({ default: 0 })
  order: number;

  @Column({ default: false })
  isPrimary: boolean;

  @Column()
  adId: string;

  @ManyToOne(() => Ad, (ad) => ad.images, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'adId' })
  ad: Ad;

  @CreateDateColumn()
  createdAt: Date;
}
