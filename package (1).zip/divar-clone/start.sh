#!/bin/bash

echo "🚀 راه‌اندازی پلتفرم دیوار کلون..."
echo ""

# بررسی Docker
if ! command -v docker &> /dev/null; then
    echo "❌ Docker یافت نشد. لطفاً ابتدا Docker را نصب کنید."
    exit 1
fi

if ! command -v docker-compose &> /dev/null; then
    echo "❌ Docker Compose یافت نشد. لطفاً ابتدا Docker Compose را نصب کنید."
    exit 1
fi

echo "✅ Docker و Docker Compose یافت شد"
echo ""

# کپی فایل‌های env
echo "📝 ایجاد فایل‌های تنظیمات..."
if [ ! -f backend/.env ]; then
    cp backend/.env.example backend/.env
    echo "✅ backend/.env ایجاد شد (لطفاً آن را ویرایش کنید)"
fi

if [ ! -f frontend/.env.local ]; then
    cp frontend/.env.example frontend/.env.local
    echo "✅ frontend/.env.local ایجاد شد"
fi

echo ""
echo "🐳 راه‌اندازی Docker Containers..."
docker-compose up -d

echo ""
echo "⏳ منتظر راه‌اندازی دیتابیس..."
sleep 10

echo ""
echo "📦 اجرای Migrations و Seed..."
docker-compose exec -T backend npm run migration:run
docker-compose exec -T backend npm run seed

echo ""
echo "✅ ✅ ✅ تبریک! سیستم با موفقیت راه‌اندازی شد ✅ ✅ ✅"
echo ""
echo "🌐 آدرس‌ها:"
echo "• Frontend: http://localhost:3000"
echo "• Backend API: http://localhost:4000"
echo "• API Docs: http://localhost:4000/api/docs"
echo "• MinIO Console: http://localhost:9001"
echo ""
echo "🔑 حساب ادمین:"
echo "• شماره: 09123456789"
echo "• کد OTP: (در حالت development هر کد 6 رقمی پذیرفته می‌شود)"
echo ""
echo "📚 برای مشاهده Logs:"
echo "docker-compose logs -f"
echo ""
echo "🛑 برای خاموش کردن:"
echo "docker-compose down"
echo ""
