# 🚀 دیوار - پلتفرم پیشرفته نیازمندی‌های آنلاین

<div align="center">

![Version](https://img.shields.io/badge/version-2.0.0-blue.svg)
![License](https://img.shields.io/badge/license-MIT-green.svg)
![Node](https://img.shields.io/badge/node-%3E%3D18.0.0-brightgreen.svg)
![Docker](https://img.shields.io/badge/docker-ready-blue.svg)

**یک پلتفرم نیازمندی‌های کامل و حرفه‌ای با معماری مدرن**

[دمو آنلاین](#) | [مستندات کامل](./COMPLETE_GUIDE.md) | [راهنمای سریع](./QUICK_START.md)

</div>

---

## ✨ ویژگی‌های برجسته

### 🎨 طراحی مدرن
- ✅ **تم تیره سه بعدی** با افکت‌های Glass Morphism
- ✅ **انیمیشن‌های نرم** و Neon Glow Effects
- ✅ **کاملاً Responsive** برای موبایل، تبلت و دسکتاپ
- ✅ **UX عالی** با طراحی کاربرپسند

### 🔐 احراز هویت پیشرفته
- ✅ ورود با **OTP (کد یکبار مصرف)**
- ✅ **JWT Tokens** (Access & Refresh)
- ✅ **Role-Based Access Control**
- ✅ سیستم امنیتی قوی

### 📢 مدیریت آگهی‌ها
- ✅ **CRUD کامل** برای آگهی‌ها
- ✅ **جستجوی پیشرفته** و فیلترهای هوشمند
- ✅ **آپلود چندین تصویر** (MinIO)
- ✅ **دسته‌بندی‌های سلسله‌مراتبی**
- ✅ **آمارگیری دقیق** (بازدید، لایک، ذخیره)

### 💬 چت Realtime
- ✅ **WebSocket** برای ارتباط لحظه‌ای
- ✅ نمایش **در حال تایپ**
- ✅ **اعلان‌های آنی**
- ✅ تاریخچه کامل پیام‌ها

### 🔍 جستجوی قدرتمند
- ✅ آماده برای **Elasticsearch**
- ✅ **فیلترهای پیشرفته** (قیمت، موقعیت، دسته)
- ✅ **Autocomplete** هوشمند
- ✅ **Full-text search**

### 🏗️ معماری حرفه‌ای
- ✅ **Microservices-Ready Architecture**
- ✅ **Docker & Docker Compose**
- ✅ **TypeORM** با PostgreSQL
- ✅ **Redis** برای کش
- ✅ **MinIO** برای ذخیره‌سازی
- ✅ **Clean Code** و **Best Practices**

---

## 🛠️ Tech Stack

### Backend
```
🔹 NestJS (Node.js Framework)
🔹 TypeScript
🔹 PostgreSQL + TypeORM
🔹 Redis (Cache & Sessions)
🔹 Passport JWT
🔹 Socket.io (WebSocket)
🔹 Swagger/OpenAPI
```

### Frontend
```
🔹 Next.js 14
🔹 React 18
🔹 TypeScript
🔹 Tailwind CSS
🔹 Axios
🔹 Socket.io Client
```

### Infrastructure
```
🔹 Docker & Docker Compose
🔹 PostgreSQL 15
🔹 Redis 7
🔹 MinIO (S3-compatible)
🔹 Elasticsearch 8
```

---

## 🚀 شروع سریع

### پیش‌نیازها
- Docker Desktop 20.10+
- Docker Compose 2.0+

### نصب و اجرا (فقط 3 دقیقه!)

```bash
# 1. کلون کردن پروژه
git clone <repository-url>
cd divar-clone

# 2. اجرا با یک دستور
./start.sh

# یا
docker-compose up --build -d

# 3. منتظر بمانید تا سرویس‌ها آماده شوند (2-3 دقیقه)
docker-compose logs -f
```

### دسترسی به برنامه

| سرویس | آدرس | توضیحات |
|-------|------|---------|
| **Frontend** | http://localhost:3000 | رابط کاربری |
| **Backend API** | http://localhost:5000/api | API سرور |
| **Swagger Docs** | http://localhost:5000/api | مستندات API |
| **MinIO Console** | http://localhost:9001 | مدیریت فایل‌ها |
| **Elasticsearch** | http://localhost:9200 | موتور جستجو |

---

## 📖 مستندات

### راهنماهای موجود
- 📘 [**COMPLETE_GUIDE.md**](./COMPLETE_GUIDE.md) - راهنمای کامل و جامع
- 📗 [**QUICK_START.md**](./QUICK_START.md) - شروع سریع
- 📕 [**FEATURES.md**](./FEATURES.md) - لیست کامل قابلیت‌ها
- 📙 [**.env.example**](./.env.example) - تنظیمات محیطی

---

## 📂 ساختار پروژه

```
divar-clone/
├── 📁 backend/              # Backend (NestJS)
│   ├── src/
│   │   ├── modules/        # ماژول‌های برنامه
│   │   │   ├── auth/       # احراز هویت
│   │   │   ├── ads/        # آگهی‌ها
│   │   │   ├── categories/ # دسته‌بندی‌ها
│   │   │   ├── chat/       # چت
│   │   │   ├── search/     # جستجو
│   │   │   └── ...
│   │   ├── database/       # دیتابیس
│   │   │   ├── entities/   # Entity ها
│   │   │   └── seeds/      # داده‌های اولیه
│   │   └── common/         # کدهای مشترک
│   └── Dockerfile
│
├── 📁 frontend/             # Frontend (Next.js)
│   ├── src/
│   │   ├── components/     # کامپوننت‌ها
│   │   │   ├── layout/     # لایه‌بندی
│   │   │   ├── ui/         # UI Components
│   │   │   └── ads/        # کامپوننت‌های آگهی
│   │   ├── pages/          # صفحات
│   │   ├── hooks/          # Custom Hooks
│   │   └── styles/         # استایل‌ها
│   └── Dockerfile.dev
│
├── 📄 docker-compose.yml   # تنظیمات Docker
├── 📄 .env.example         # مثال تنظیمات
└── 📄 README.md           # این فایل
```

---

## 🎯 API Endpoints

### Authentication
```http
POST   /api/auth/send-otp       # ارسال کد OTP
POST   /api/auth/verify-otp     # تایید کد OTP
POST   /api/auth/refresh        # تمدید توکن
```

### Ads
```http
GET    /api/ads                 # لیست آگهی‌ها
POST   /api/ads                 # ثبت آگهی جدید
GET    /api/ads/:id             # جزئیات آگهی
PATCH  /api/ads/:id             # ویرایش آگهی
DELETE /api/ads/:id             # حذف آگهی
```

### Categories
```http
GET    /api/categories          # لیست دسته‌بندی‌ها
GET    /api/categories/:id      # جزئیات دسته
```

### Chat
```http
GET    /api/chat/conversations  # لیست مکالمات
GET    /api/chat/messages/:id   # پیام‌های یک مکالمه
POST   /api/chat/messages       # ارسال پیام
```

### Search
```http
GET    /api/search?q=...        # جستجو
GET    /api/search/autocomplete # پیشنهاد خودکار
```

**مستندات کامل API:** http://localhost:5000/api

---

## 🖼️ اسکرین‌شات‌ها

<div align="center">

### صفحه اصلی
![Homepage](docs/screenshots/home.png)

### داشبورد کاربر
![Dashboard](docs/screenshots/dashboard.png)

### ثبت آگهی
![Create Ad](docs/screenshots/create-ad.png)

</div>

---

## 🔧 توسعه

### راه‌اندازی محیط Development

```bash
# Backend
cd backend
npm install
npm run start:dev

# Frontend
cd frontend
npm install
npm run dev
```

### اجرای Seed
```bash
cd backend
npm run seed
```

### Testing
```bash
# Unit Tests
npm run test

# E2E Tests
npm run test:e2e

# Coverage
npm run test:cov
```

---

## 🗺️ Roadmap

### ✅ نسخه 1.0 (کامل شده)
- [x] Authentication System
- [x] Ad CRUD
- [x] Category Management
- [x] Basic Search
- [x] File Upload
- [x] WebSocket Chat
- [x] User Dashboard

### 🚧 نسخه 2.0 (در حال توسعه)
- [ ] Elasticsearch Integration
- [ ] Admin Panel
- [ ] Payment Gateway
- [ ] Push Notifications
- [ ] Map & Location
- [ ] ML Recommendations

### 💡 نسخه 3.0 (برنامه آینده)
- [ ] Mobile App
- [ ] PWA Support
- [ ] Voice Search
- [ ] AR/VR Features
- [ ] Blockchain Integration

---

## 🤝 مشارکت

مشارکت شما خوشحال‌مان می‌کند! 

1. Fork کنید
2. Branch جدید بسازید (`git checkout -b feature/AmazingFeature`)
3. Commit کنید (`git commit -m 'Add some AmazingFeature'`)
4. Push کنید (`git push origin feature/AmazingFeature`)
5. Pull Request باز کنید

---

## 📝 License

این پروژه تحت لایسنس MIT منتشر شده است. برای جزئیات بیشتر [LICENSE](LICENSE) را ببینید.

---

## 👨‍💻 توسعه‌دهنده

**ساخته شده توسط:** MiniMax Agent

برای پشتیبانی و سوالات:
- 📧 Email: support@divar.example
- 💬 Telegram: @divar_support
- 🌐 Website: https://divar.example

---

## 🌟 حمایت

اگر این پروژه برایتان مفید بود، لطفاً با دادن ⭐️ از ما حمایت کنید!

---

<div align="center">

**Made with ❤️ by MiniMax Agent**

**© 2025 Divar Platform. All Rights Reserved.**

</div>
