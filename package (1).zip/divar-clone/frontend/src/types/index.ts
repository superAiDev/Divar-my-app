export interface User {
  id: string;
  phone: string;
  name?: string;
  email?: string;
  avatar?: string;
  role: string;
  createdAt: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description?: string;
  icon?: string;
  image?: string;
  order: number;
  isActive: boolean;
  parentId?: string;
  parent?: Category;
  children?: Category[];
}

export enum AdStatus {
  DRAFT = 'draft',
  PENDING = 'pending',
  ACTIVE = 'active',
  SOLD = 'sold',
  EXPIRED = 'expired',
  REJECTED = 'rejected',
}

export enum AdCondition {
  NEW = 'new',
  LIKE_NEW = 'like_new',
  GOOD = 'good',
  FAIR = 'fair',
}

export interface Ad {
  id: string;
  title: string;
  description: string;
  price: number;
  isNegotiable: boolean;
  condition?: AdCondition;
  status: AdStatus;
  views: number;
  userId: string;
  categoryId: string;
  category?: Category;
  user?: User;
  images?: AdImage[];
  createdAt: string;
  updatedAt: string;
}

export interface AdImage {
  id: string;
  url: string;
  thumbnail?: string;
  order: number;
  isPrimary: boolean;
}

export interface Conversation {
  id: string;
  user1Id: string;
  user2Id: string;
  lastMessageAt?: string;
  lastMessageText?: string;
  otherUser?: User;
}

export interface Message {
  id: string;
  content: string;
  isRead: boolean;
  senderId: string;
  conversationId: string;
  sender?: User;
  createdAt: string;
}

export interface Notification {
  id: string;
  title: string;
  content: string;
  type: string;
  isRead: boolean;
  data?: any;
  createdAt: string;
}

export interface PaginationMeta {
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}

export interface PaginatedResponse<T> {
  data: T[];
  meta: PaginationMeta;
}
