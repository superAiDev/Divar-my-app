import React from 'react';
import Link from 'next/link';
import { useAuth } from '../hooks/useAuth';

export default function Layout({ children }: { children: React.ReactNode }) {
  const { user, isAuthenticated, logout } = useAuth();

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="text-2xl font-bold text-primary-600">
              دیوار
            </Link>

            <nav className="flex items-center gap-6">
              {isAuthenticated ? (
                <>
                  <Link href="/ads/new" className="btn-primary">
                    ثبت آگهی
                  </Link>
                  <Link href="/profile" className="text-gray-700 hover:text-primary-600">
                    پروفایل
                  </Link>
                  <button onClick={logout} className="text-gray-700 hover:text-primary-600">
                    خروج
                  </button>
                </>
              ) : (
                <Link href="/auth/login" className="btn-primary">
                  ورود
                </Link>
              )}
            </nav>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-gray-800 text-white mt-16">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center">
            <p>© 2025 دیوار کلون - تمامی حقوق محفوظ است</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
