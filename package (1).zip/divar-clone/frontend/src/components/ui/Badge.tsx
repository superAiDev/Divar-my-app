import React from 'react';

interface BadgeProps {
  children: React.ReactNode;
  variant?: 'default' | 'success' | 'error' | 'warning' | 'info' | 'primary';
  size?: 'sm' | 'md' | 'lg';
  rounded?: boolean;
}

const Badge: React.FC<BadgeProps> = ({ children, variant = 'default', size = 'md', rounded = false }) => {
  const variants = {
    default: 'bg-gray-700/50 text-gray-300 border-gray-600',
    success: 'bg-green-500/20 text-green-400 border-green-500',
    error: 'bg-red-500/20 text-red-400 border-red-500',
    warning: 'bg-yellow-500/20 text-yellow-400 border-yellow-500',
    info: 'bg-blue-500/20 text-blue-400 border-blue-500',
    primary: 'bg-purple-500/20 text-purple-400 border-purple-500',
  };

  const sizes = {
    sm: 'text-xs px-2 py-0.5',
    md: 'text-sm px-3 py-1',
    lg: 'text-base px-4 py-1.5',
  };

  return (
    <span
      className={`inline-flex items-center border font-medium ${rounded ? 'rounded-full' : 'rounded-lg'} ${variants[variant]} ${sizes[size]}`}
    >
      {children}
    </span>
  );
};

export default Badge;
