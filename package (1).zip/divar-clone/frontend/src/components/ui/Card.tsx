import React from 'react';
import clsx from 'clsx';

interface CardProps {
  children: React.ReactNode;
  className?: string;
  hover?: boolean;
  glass?: boolean;
}

export const Card: React.FC<CardProps> = ({
  children,
  className,
  hover = false,
  glass = true,
}) => {
  return (
    <div
      className={clsx(
        'rounded-xl p-6',
        glass && 'glass',
        hover && 'card-hover cursor-pointer',
        className
      )}
    >
      {children}
    </div>
  );
};
