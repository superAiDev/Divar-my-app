import { useState } from 'react';

interface SearchBarProps {
  onSearch: (query: string) => void;
  placeholder?: string;
}

export default function SearchBar({ onSearch, placeholder = 'جستجو در همه آگهی‌ها...' }: SearchBarProps) {
  const [query, setQuery] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(query);
  };

  return (
    <form onSubmit={handleSubmit} className="w-full">
      <div className="glass-effect rounded-lg p-2 flex gap-2">
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={placeholder}
          className="flex-1 px-6 py-4 bg-transparent text-white placeholder-gray-500 focus:outline-none"
        />
        <button
          type="submit"
          className="gradient-primary px-8 py-4 rounded-lg text-white font-medium hover:opacity-90 transition neon-glow"
        >
          جستجو
        </button>
      </div>
    </form>
  );
}
