import { useState, useEffect, useRef } from 'react';
import { io, Socket } from 'socket.io-client';
import Card from '../ui/Card';
import Input from '../ui/Input';
import Button from '../ui/Button';

interface Message {
  id: string;
  content: string;
  senderId: string;
  createdAt: string;
}

interface ChatBoxProps {
  conversationId: string;
  currentUserId: string;
}

export default function ChatBox({ conversationId, currentUserId }: ChatBoxProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [socket, setSocket] = useState<Socket | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Connect to WebSocket
    const newSocket = io(process.env.NEXT_PUBLIC_WS_URL || 'ws://localhost:5000');
    setSocket(newSocket);

    // Join conversation room
    newSocket.emit('joinRoom', conversationId);

    // Listen for new messages
    newSocket.on('newMessage', (message: Message) => {
      setMessages(prev => [...prev, message]);
    });

    // Listen for typing indicator
    newSocket.on('userTyping', ({ isTyping }: { isTyping: boolean }) => {
      setIsTyping(isTyping);
    });

    return () => {
      newSocket.close();
    };
  }, [conversationId]);

  useEffect(() => {
    // Scroll to bottom when new message arrives
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = () => {
    if (!newMessage.trim() || !socket) return;

    socket.emit('sendMessage', {
      room: conversationId,
      userId: currentUserId,
      message: newMessage,
    });

    setNewMessage('');
  };

  const handleTyping = (e: React.ChangeEvent<HTMLInputElement>) => {
    setNewMessage(e.target.value);
    
    if (socket) {
      socket.emit('typing', {
        room: conversationId,
        userId: currentUserId,
        isTyping: e.target.value.length > 0,
      });
    }
  };

  return (
    <Card className="h-[600px] flex flex-col">
      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${
              message.senderId === currentUserId ? 'justify-end' : 'justify-start'
            }`}
          >
            <div
              className={`max-w-[70%] px-4 py-2 rounded-lg ${
                message.senderId === currentUserId
                  ? 'gradient-primary text-white'
                  : 'glass-effect text-white'
              }`}
            >
              <p>{message.content}</p>
              <p className="text-xs opacity-70 mt-1">
                {new Date(message.createdAt).toLocaleTimeString('fa-IR')}
              </p>
            </div>
          </div>
        ))}
        {isTyping && (
          <div className="flex justify-start">
            <div className="glass-effect px-4 py-2 rounded-lg">
              <span className="text-gray-400 text-sm">در حال تایپ...</span>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="p-4 border-t border-white/10">
        <div className="flex gap-2">
          <input
            type="text"
            value={newMessage}
            onChange={handleTyping}
            onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
            placeholder="پیام خود را بنویسید..."
            className="flex-1 px-4 py-3 glass-effect rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-purple-500"
          />
          <Button onClick={handleSendMessage}>
            ارسال
          </Button>
        </div>
      </div>
    </Card>
  );
}
