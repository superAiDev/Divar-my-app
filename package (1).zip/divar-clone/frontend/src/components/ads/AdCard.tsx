import Link from 'next/link';
import Image from 'next/image';

interface AdCardProps {
  id: string;
  title: string;
  description: string;
  price: number | null;
  city: string;
  image?: string;
  createdAt: string;
}

export default function AdCard({ id, title, description, price, city, image, createdAt }: AdCardProps) {
  return (
    <Link href={`/ads/${id}`}>
      <div className="glass-effect rounded-xl overflow-hidden card-3d cursor-pointer group">
        {/* Image */}
        <div className="h-48 bg-gradient-to-br from-purple-500 via-pink-500 to-blue-500 relative overflow-hidden">
          {image ? (
            <Image
              src={image}
              alt={title}
              fill
              className="object-cover group-hover:scale-110 transition-transform duration-500"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-6xl">
              📦
            </div>
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
        </div>

        {/* Content */}
        <div className="p-4">
          <h3 className="font-semibold text-white mb-2 line-clamp-1 group-hover:text-purple-400 transition">
            {title}
          </h3>
          <p className="text-sm text-gray-400 mb-3 line-clamp-2">
            {description}
          </p>
          <div className="flex justify-between items-center">
            <span className="text-lg font-bold text-gradient">
              {price ? `${price.toLocaleString('fa-IR')} تومان` : 'توافقی'}
            </span>
            <span className="text-xs text-gray-500">{city}</span>
          </div>
          <div className="mt-2 text-xs text-gray-500">
            {new Date(createdAt).toLocaleDateString('fa-IR')}
          </div>
        </div>
      </div>
    </Link>
  );
}
