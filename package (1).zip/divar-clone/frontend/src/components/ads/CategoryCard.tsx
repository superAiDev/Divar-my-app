import Link from 'next/link';

interface CategoryCardProps {
  id: string;
  name: string;
  icon: string;
  count: number;
}

export default function CategoryCard({ id, name, icon, count }: CategoryCardProps) {
  return (
    <Link href={`/category/${id}`}>
      <div className="glass-effect p-6 rounded-xl text-center card-3d cursor-pointer group">
        <div className="text-5xl mb-3 group-hover:scale-125 transition-transform">
          {icon}
        </div>
        <h3 className="font-semibold text-white mb-1 group-hover:text-gradient transition">
          {name}
        </h3>
        <p className="text-sm text-gray-400">
          {count.toLocaleString('fa-IR')} آگهی
        </p>
      </div>
    </Link>
  );
}
