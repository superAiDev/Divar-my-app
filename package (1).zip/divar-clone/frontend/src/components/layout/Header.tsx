import React, { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/router';
import { useAuth } from '../../hooks/useAuth';
import { Button } from '../ui';

export const Header: React.FC = () => {
  const router = useRouter();
  const { user, isAuthenticated, logout } = useAuth();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleLogout = () => {
    logout();
    router.push('/');
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 glass-strong">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-2 space-x-reverse">
            <div className="w-10 h-10 bg-gradient-to-r from-purple-600 to-pink-600 rounded-lg flex items-center justify-center neon-glow">
              <span className="text-white font-bold text-xl">د</span>
            </div>
            <span className="text-xl font-bold gradient-text hidden sm:block">دیوار</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6 space-x-reverse">
            <Link href="/" className="text-gray-300 hover:text-white transition-colors">
              خانه
            </Link>
            <Link href="/ads" className="text-gray-300 hover:text-white transition-colors">
              آگهی‌ها
            </Link>
            {isAuthenticated && (
              <>
                <Link href="/dashboard" className="text-gray-300 hover:text-white transition-colors">
                  دشبرد
                </Link>
                <Link href="/chat" className="text-gray-300 hover:text-white transition-colors">
                  پیام‌ها
                </Link>
              </>
            )}
          </nav>

          {/* CTA Buttons */}
          <div className="hidden md:flex items-center space-x-4 space-x-reverse">
            {isAuthenticated ? (
              <>
                <Link href="/ads/create">
                  <Button variant="primary" size="sm">
                    ثبت آگهی
                  </Button>
                </Link>
                <button
                  onClick={handleLogout}
                  className="text-gray-300 hover:text-white transition-colors px-4 py-2"
                >
                  خروج
                </button>
              </>
            ) : (
              <Link href="/auth/login">
                <Button variant="primary" size="sm">
                  ورود
                </Button>
              </Link>
            )}
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden text-white p-2"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              {isMenuOpen ? (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              )}
            </svg>
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden py-4 space-y-2">
            <Link href="/" className="block py-2 text-gray-300 hover:text-white">
              خانه
            </Link>
            <Link href="/ads" className="block py-2 text-gray-300 hover:text-white">
              آگهی‌ها
            </Link>
            {isAuthenticated ? (
              <>
                <Link href="/dashboard" className="block py-2 text-gray-300 hover:text-white">
                  دشبرد
                </Link>
                <Link href="/chat" className="block py-2 text-gray-300 hover:text-white">
                  پیام‌ها
                </Link>
                <Link href="/ads/create" className="block py-2">
                  <Button variant="primary" size="sm" className="w-full">
                    ثبت آگهی
                  </Button>
                </Link>
                <button
                  onClick={handleLogout}
                  className="block w-full text-right py-2 text-gray-300 hover:text-white"
                >
                  خروج
                </button>
              </>
            ) : (
              <Link href="/auth/login" className="block py-2">
                <Button variant="primary" size="sm" className="w-full">
                  ورود
                </Button>
              </Link>
            )}
          </div>
        )}
      </div>
    </header>
  );
};
