import React, { useState } from 'react';
import Head from 'next/head';
import { useRouter } from 'next/router';
import { useAuth } from '../../hooks/useAuth';
import { Button, Card, Input } from '../../components/ui';
import toast from 'react-hot-toast';

export default function Login() {
  const router = useRouter();
  const { sendOtp, login, isLoading } = useAuth();
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [step, setStep] = useState<'phone' | 'otp'>('phone');

  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await sendOtp(phone);
      setStep('otp');
      toast.success('کد تایید ارسال شد');
    } catch (error: any) {
      toast.error(error.response?.data?.message || 'خطا در ارسال کد');
    }
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await login(phone, otp);
      toast.success('ورود موفق');
      router.push('/dashboard');
    } catch (error: any) {
      toast.error(error.response?.data?.message || 'کد نامعتبر است');
    }
  };

  return (
    <>
      <Head>
        <title>ورود به دیوار</title>
      </Head>

      <div className="min-h-screen flex items-center justify-center px-4 py-12">
        <Card className="w-full max-w-md">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold mb-2">
              <span className="gradient-text">خوش آمدید</span>
            </h1>
            <p className="text-gray-400">
              {step === 'phone' 
                ? 'لطفا شماره موبایل خود را وارد کنید'
                : 'کد تایید ارسالی را وارد کنید'
              }
            </p>
          </div>

          {step === 'phone' ? (
            <form onSubmit={handleSendOtp} className="space-y-6">
              <Input
                type="tel"
                label="شماره موبایل"
                placeholder="09123456789"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                required
                pattern="09[0-9]{9}"
              />
              <Button type="submit" variant="primary" className="w-full" disabled={isLoading}>
                {isLoading ? 'در حال ارسال...' : 'ارسال کد'}
              </Button>
            </form>
          ) : (
            <form onSubmit={handleVerifyOtp} className="space-y-6">
              <Input
                type="text"
                label="کد تایید"
                placeholder="123456"
                value={otp}
                onChange={(e) => setOtp(e.target.value)}
                required
                maxLength={6}
              />
              <Button type="submit" variant="primary" className="w-full" disabled={isLoading}>
                {isLoading ? 'در حال بررسی...' : 'تایید و ورود'}
              </Button>
              <button
                type="button"
                onClick={() => setStep('phone')}
                className="text-sm text-gray-400 hover:text-white transition-colors w-full text-center"
              >
                بازگشت به ورود شماره
              </button>
            </form>
          )}

          {step === 'otp' && (
            <div className="mt-4 p-4 bg-blue-500/10 border border-blue-500/30 rounded-lg">
              <p className="text-sm text-blue-400">
                🔑 در محیط توسعه، کد OTP در کنسول نمایش داده می‌شود.
              </p>
            </div>
          )}
        </Card>
      </div>
    </>
  );
}
