import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import { useRouter } from 'next/router';
import { useAuth } from '../../hooks/useAuth';
import { Button, Card, Input } from '../../components/ui';
import api from '../../lib/api';
import { Category } from '../../types';
import toast from 'react-hot-toast';

export default function CreateAd() {
  const router = useRouter();
  const { isAuthenticated } = useAuth();
  const [categories, setCategories] = useState<Category[]>([]);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    price: '',
    categoryId: '',
    isNegotiable: true,
  });
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (!isAuthenticated) {
      router.push('/auth/login');
      return;
    }
    fetchCategories();
  }, [isAuthenticated]);

  const fetchCategories = async () => {
    try {
      const response = await api.get('/categories');
      setCategories(response.data);
    } catch (error) {
      console.error('Failed to fetch categories:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const data = {
        ...formData,
        price: parseFloat(formData.price),
      };
      
      const response = await api.post('/ads', data);
      toast.success('آگهی با موفقیت ثبت شد');
      router.push(`/ads/${response.data.id}`);
    } catch (error: any) {
      toast.error(error.response?.data?.message || 'خطا در ثبت آگهی');
    } finally {
      setIsLoading(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : value,
    }));
  };

  if (!isAuthenticated) {
    return null;
  }

  return (
    <>
      <Head>
        <title>ثبت آگهی | دیوار</title>
      </Head>

      <div className="container mx-auto px-4 py-12">
        <div className="max-w-3xl mx-auto">
          <Card>
            <h1 className="text-3xl font-bold mb-6">
              <span className="gradient-text">ثبت آگهی جدید</span>
            </h1>

            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Title */}
              <Input
                label="عنوان آگهی"
                name="title"
                value={formData.title}
                onChange={handleChange}
                required
                placeholder="مثلا: iPhone 15 Pro Max"
              />

              {/* Category */}
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  دسته‌بندی
                </label>
                <select
                  name="categoryId"
                  value={formData.categoryId}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 rounded-lg bg-gray-800/50 border border-gray-700 text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                >
                  <option value="">انتخاب دسته‌بندی</option>
                  {categories.map((cat) => (
                    <option key={cat.id} value={cat.id}>
                      {cat.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Description */}
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  توضیحات
                </label>
                <textarea
                  name="description"
                  value={formData.description}
                  onChange={handleChange}
                  required
                  rows={6}
                  placeholder="توضیحات کامل درباره کالا یا خدمت خود را بنویسید..."
                  className="w-full px-4 py-3 rounded-lg bg-gray-800/50 border border-gray-700 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-purple-500 resize-none"
                />
              </div>

              {/* Price */}
              <Input
                label="قیمت (تومان)"
                name="price"
                type="number"
                value={formData.price}
                onChange={handleChange}
                required
                placeholder="1000000"
              />

              {/* Negotiable */}
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="isNegotiable"
                  name="isNegotiable"
                  checked={formData.isNegotiable}
                  onChange={handleChange}
                  className="w-5 h-5 rounded border-gray-700 bg-gray-800 text-purple-600 focus:ring-purple-500"
                />
                <label htmlFor="isNegotiable" className="text-gray-300">
                  قابل چانه‌زنی
                </label>
              </div>

              {/* Submit Button */}
              <div className="flex gap-4">
                <Button
                  type="submit"
                  variant="primary"
                  className="flex-1"
                  disabled={isLoading}
                >
                  {isLoading ? 'در حال ثبت...' : 'ثبت آگهی'}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => router.back()}
                  disabled={isLoading}
                >
                  انصراف
                </Button>
              </div>
            </form>
          </Card>
        </div>
      </div>
    </>
  );
}
