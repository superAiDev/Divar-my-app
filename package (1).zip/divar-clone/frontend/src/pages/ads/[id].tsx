import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import { Layout } from '../../components/layout';
import { Badge, Spinner, Button, Tabs, Modal } from '../../components/ui';
import api from '../../lib/api';
import { formatPrice, formatDate } from '../../utils/format';

interface Ad {
  id: string;
  title: string;
  description: string;
  price: number;
  images: Array<{ url: string; isPrimary: boolean }>;
  category: { name: string };
  location: { city: string; province: string };
  status: string;
  createdAt: string;
  user: {
    id: string;
    name: string;
    avatar?: string;
  };
  customFields?: Record<string, any>;
}

interface Review {
  id: string;
  rating: number;
  comment: string;
  user: { name: string; avatar?: string };
  createdAt: string;
}

const AdDetailPage = () => {
  const router = useRouter();
  const { id } = router.query;
  const [ad, setAd] = useState<Ad | null>(null);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [averageRating, setAverageRating] = useState(0);
  const [loading, setLoading] = useState(true);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [showContactModal, setShowContactModal] = useState(false);
  const [isFavorite, setIsFavorite] = useState(false);

  useEffect(() => {
    if (id) {
      fetchAdDetails();
      fetchReviews();
      checkFavorite();
    }
  }, [id]);

  const fetchAdDetails = async () => {
    try {
      const response = await api.get(`/ads/${id}`);
      setAd(response.data);
    } catch (error) {
      console.error('Error fetching ad:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchReviews = async () => {
    try {
      const response = await api.get(`/reviews/ad/${id}`);
      setReviews(response.data.data);
      setAverageRating(response.data.meta.averageRating);
    } catch (error) {
      console.error('Error fetching reviews:', error);
    }
  };

  const checkFavorite = async () => {
    try {
      const response = await api.get(`/favorites/check/${id}`);
      setIsFavorite(response.data.isFavorite);
    } catch (error) {
      console.error('Error checking favorite:', error);
    }
  };

  const toggleFavorite = async () => {
    try {
      if (isFavorite) {
        await api.delete(`/favorites/${id}`);
        setIsFavorite(false);
      } else {
        await api.post('/favorites', { adId: id });
        setIsFavorite(true);
      }
    } catch (error) {
      console.error('Error toggling favorite:', error);
    }
  };

  if (loading) {
    return (
      <Layout>
        <Spinner fullScreen />
      </Layout>
    );
  }

  if (!ad) {
    return (
      <Layout>
        <div className="flex flex-col items-center justify-center min-h-screen">
          <h1 className="text-2xl font-bold text-white mb-4">آگهی یافت نشد</h1>
          <Button onClick={() => router.push('/')}>بازگشت به صفحه اصلی</Button>
        </div>
      </Layout>
    );
  }

  const statusColors: Record<string, string> = {
    active: 'success',
    pending: 'warning',
    rejected: 'error',
    expired: 'default',
  };

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Images Gallery */}
            <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-2xl overflow-hidden border border-gray-700/50">
              <div className="relative aspect-video">
                <img
                  src={ad.images[currentImageIndex]?.url || '/placeholder.jpg'}
                  alt={ad.title}
                  className="w-full h-full object-cover"
                />
                
                {/* Navigation Arrows */}
                {ad.images.length > 1 && (
                  <>
                    <button
                      onClick={() => setCurrentImageIndex((prev) => (prev - 1 + ad.images.length) % ad.images.length)}
                      className="absolute left-4 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white p-3 rounded-full transition"
                    >
                      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                      </svg>
                    </button>
                    <button
                      onClick={() => setCurrentImageIndex((prev) => (prev + 1) % ad.images.length)}
                      className="absolute right-4 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white p-3 rounded-full transition"
                    >
                      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                      </svg>
                    </button>
                  </>
                )}
              </div>

              {/* Thumbnails */}
              {ad.images.length > 1 && (
                <div className="flex gap-2 p-4 overflow-x-auto">
                  {ad.images.map((image, index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentImageIndex(index)}
                      className={`flex-shrink-0 w-20 h-20 rounded-lg overflow-hidden border-2 transition ${
                        currentImageIndex === index
                          ? 'border-blue-500'
                          : 'border-gray-700 hover:border-gray-600'
                      }`}
                    >
                      <img src={image.url} alt={`Thumbnail ${index + 1}`} className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Ad Details */}
            <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-2xl p-6 border border-gray-700/50">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h1 className="text-3xl font-bold text-white mb-2">{ad.title}</h1>
                  <div className="flex items-center gap-3">
                    <Badge variant={statusColors[ad.status] as any}>{ad.status}</Badge>
                    <span className="text-gray-400 text-sm">{formatDate(ad.createdAt)}</span>
                  </div>
                </div>
                <button
                  onClick={toggleFavorite}
                  className={`p-3 rounded-full transition ${
                    isFavorite
                      ? 'bg-red-500/20 text-red-400'
                      : 'bg-gray-700/50 text-gray-400 hover:text-red-400'
                  }`}
                >
                  <svg className="w-6 h-6" fill={isFavorite ? 'currentColor' : 'none'} viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                  </svg>
                </button>
              </div>

              <div className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-400 mb-6">
                {formatPrice(ad.price)} تومان
              </div>

              <div className="prose prose-invert max-w-none">
                <h3 className="text-lg font-semibold text-white mb-3">توضیحات</h3>
                <p className="text-gray-300 whitespace-pre-wrap">{ad.description}</p>
              </div>

              {/* Custom Fields */}
              {ad.customFields && Object.keys(ad.customFields).length > 0 && (
                <div className="mt-6 pt-6 border-t border-gray-700/50">
                  <h3 className="text-lg font-semibold text-white mb-4">مشخصات</h3>
                  <div className="grid grid-cols-2 gap-4">
                    {Object.entries(ad.customFields).map(([key, value]) => (
                      <div key={key} className="flex justify-between">
                        <span className="text-gray-400">{key}:</span>
                        <span className="text-white font-medium">{value as string}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Reviews */}
            <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-2xl p-6 border border-gray-700/50">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-white">نظرات کاربران</h2>
                {averageRating > 0 && (
                  <div className="flex items-center gap-2">
                    <div className="flex text-yellow-400">
                      {[...Array(5)].map((_, i) => (
                        <svg
                          key={i}
                          className={`w-5 h-5 ${
                            i < Math.floor(averageRating) ? 'fill-current' : 'fill-none'
                          }`}
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" />
                        </svg>
                      ))}
                    </div>
                    <span className="text-white font-bold">{averageRating.toFixed(1)}</span>
                  </div>
                )}
              </div>

              <div className="space-y-4">
                {reviews.length > 0 ? (
                  reviews.map((review) => (
                    <div key={review.id} className="bg-gray-800/50 rounded-xl p-4">
                      <div className="flex items-start gap-3">
                        <img
                          src={review.user.avatar || '/default-avatar.png'}
                          alt={review.user.name}
                          className="w-10 h-10 rounded-full"
                        />
                        <div className="flex-1">
                          <div className="flex items-center justify-between mb-2">
                            <span className="font-semibold text-white">{review.user.name}</span>
                            <div className="flex text-yellow-400">
                              {[...Array(review.rating)].map((_, i) => (
                                <svg key={i} className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                                  <path d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" />
                                </svg>
                              ))}
                            </div>
                          </div>
                          <p className="text-gray-300 text-sm">{review.comment}</p>
                          <span className="text-gray-500 text-xs mt-2 block">{formatDate(review.createdAt)}</span>
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-center text-gray-400 py-8">هنوز نظری ثبت نشده است</p>
                )}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Seller Info */}
            <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-2xl p-6 border border-gray-700/50 sticky top-24">
              <div className="flex items-center gap-3 mb-6">
                <img
                  src={ad.user.avatar || '/default-avatar.png'}
                  alt={ad.user.name}
                  className="w-16 h-16 rounded-full border-2 border-blue-500"
                />
                <div>
                  <h3 className="font-bold text-white">{ad.user.name}</h3>
                  <span className="text-sm text-gray-400">آگهی‌دهنده</span>
                </div>
              </div>

              <div className="space-y-3">
                <Button
                  onClick={() => setShowContactModal(true)}
                  className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                >
                  <svg className="w-5 h-5 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                  </svg>
                  تماس با آگهی‌دهنده
                </Button>

                <Button
                  onClick={() => router.push(`/chat?adId=${id}`)}
                  className="w-full bg-gray-700 hover:bg-gray-600"
                >
                  <svg className="w-5 h-5 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                  </svg>
                  ارسال پیام
                </Button>
              </div>

              <div className="mt-6 pt-6 border-t border-gray-700/50 space-y-3">
                <div className="flex items-center gap-2 text-gray-300">
                  <svg className="w-5 h-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                  </svg>
                  <span>{ad.location.city}, {ad.location.province}</span>
                </div>

                <div className="flex items-center gap-2 text-gray-300">
                  <svg className="w-5 h-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z" />
                  </svg>
                  <span>{ad.category.name}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Contact Modal */}
      <Modal isOpen={showContactModal} onClose={() => setShowContactModal(false)} title="تماس با آگهی‌دهنده">
        <div className="space-y-4">
          <p className="text-gray-300">برای برقراری تماس با فروشنده، از شماره زیر استفاده کنید:</p>
          <div className="bg-gray-800/50 rounded-xl p-4 text-center">
            <p className="text-2xl font-bold text-white dir-ltr">0912-XXX-XXXX</p>
            <p className="text-sm text-gray-400 mt-2">شماره پس از ورود به حساب کاربری نمایش داده می‌شود</p>
          </div>
        </div>
      </Modal>
    </Layout>
  );
};

export default AdDetailPage;
