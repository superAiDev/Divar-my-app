import React, { useEffect, useState } from 'react';
import Head from 'next/head';
import Link from 'next/link';
import { useRouter } from 'next/router';
import { useAuth } from '../hooks/useAuth';
import { Button, Card } from '../components/ui';
import api from '../lib/api';
import { Ad } from '../types';
import { formatPrice, formatRelativeTime } from '../utils/format';

export default function Dashboard() {
  const router = useRouter();
  const { user, isAuthenticated } = useAuth();
  const [myAds, setMyAds] = useState<Ad[]>([]);
  const [stats, setStats] = useState({ total: 0, active: 0, views: 0 });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (!isAuthenticated) {
      router.push('/auth/login');
      return;
    }
    fetchMyAds();
  }, [isAuthenticated]);

  const fetchMyAds = async () => {
    try {
      const response = await api.get('/ads/my-ads');
      const ads = response.data.data;
      setMyAds(ads);
      
      const total = ads.length;
      const active = ads.filter((ad: Ad) => ad.status === 'active').length;
      const views = ads.reduce((sum: number, ad: Ad) => sum + ad.views, 0);
      setStats({ total, active, views });
    } catch (error) {
      console.error('Failed to fetch ads:', error);
    } finally {
      setIsLoading(false);
    }
  };

  if (!isAuthenticated) {
    return null;
  }

  return (
    <>
      <Head>
        <title>دشبرد | دیوار</title>
      </Head>

      <div className="container mx-auto px-4 py-12">
        {/* Welcome */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">
            سلام <span className="gradient-text">{user?.name || user?.phone}</span>
          </h1>
          <p className="text-gray-400">به پنل کاربری خود خوش آمدید</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <Card>
            <div className="text-center">
              <div className="text-4xl font-bold gradient-text mb-2">{stats.total}</div>
              <div className="text-gray-400">کل آگهی‌ها</div>
            </div>
          </Card>
          <Card>
            <div className="text-center">
              <div className="text-4xl font-bold text-green-500 mb-2">{stats.active}</div>
              <div className="text-gray-400">آگهی‌های فعال</div>
            </div>
          </Card>
          <Card>
            <div className="text-center">
              <div className="text-4xl font-bold text-blue-500 mb-2">{stats.views}</div>
              <div className="text-gray-400">کل بازدیدها</div>
            </div>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <Link href="/ads/create">
            <Card hover className="text-center">
              <div className="text-5xl mb-4">➕</div>
              <h3 className="font-semibold">ثبت آگهی جدید</h3>
            </Card>
          </Link>
          <Link href="/chat">
            <Card hover className="text-center">
              <div className="text-5xl mb-4">💬</div>
              <h3 className="font-semibold">پیام‌ها</h3>
            </Card>
          </Link>
          <Link href="/favorites">
            <Card hover className="text-center">
              <div className="text-5xl mb-4">❤️</div>
              <h3 className="font-semibold">علاقه‌مندی‌ها</h3>
            </Card>
          </Link>
        </div>

        {/* My Ads */}
        <div>
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold">آگهی‌های من</h2>
            <Link href="/ads/create">
              <Button variant="primary" size="sm">
                ثبت آگهی جدید
              </Button>
            </Link>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[...Array(3)].map((_, i) => (
                <Card key={i} className="h-48 animate-pulse" />
              ))}
            </div>
          ) : myAds.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {myAds.map((ad) => (
                <Card key={ad.id} hover>
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h3 className="font-semibold mb-1 line-clamp-2">{ad.title}</h3>
                      <p className="text-lg font-bold gradient-text">
                        {formatPrice(ad.price)} تومان
                      </p>
                    </div>
                    <span className={`px-2 py-1 rounded text-xs ${
                      ad.status === 'active' ? 'bg-green-500/20 text-green-400' :
                      ad.status === 'pending' ? 'bg-yellow-500/20 text-yellow-400' :
                      'bg-gray-500/20 text-gray-400'
                    }`}>
                      {ad.status === 'active' ? 'فعال' :
                       ad.status === 'pending' ? 'در انتظار' :
                       ad.status === 'sold' ? 'فروخته شده' : 'غیرفعال'}
                    </span>
                  </div>
                  <div className="flex justify-between items-center text-sm text-gray-400">
                    <span>👁 {ad.views} بازدید</span>
                    <span>{formatRelativeTime(ad.createdAt)}</span>
                  </div>
                  <div className="mt-4 flex gap-2">
                    <Link href={`/ads/${ad.id}`} className="flex-1">
                      <Button variant="outline" size="sm" className="w-full">
                        مشاهده
                      </Button>
                    </Link>
                    <Link href={`/ads/edit/${ad.id}`} className="flex-1">
                      <Button variant="secondary" size="sm" className="w-full">
                        ویرایش
                      </Button>
                    </Link>
                  </div>
                </Card>
              ))}
            </div>
          ) : (
            <Card className="text-center py-12">
              <div className="text-6xl mb-4">📢</div>
              <h3 className="text-xl font-semibold mb-2">هنوز آگهی ثبت نکرده‌اید</h3>
              <p className="text-gray-400 mb-6">اولین آگهی خود را ایجاد کنید</p>
              <Link href="/ads/create">
                <Button variant="primary">
                  ثبت آگهی اول
                </Button>
              </Link>
            </Card>
          )}
        </div>
      </div>
    </>
  );
}
