import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import Link from 'next/link';
import { useRouter } from 'next/router';
import { Button, Card, Input } from '../components/ui';
import api from '../lib/api';
import { Ad, Category } from '../types';
import { formatPrice, formatRelativeTime } from '../utils/format';

export default function Home() {
  const router = useRouter();
  const [searchQuery, setSearchQuery] = useState('');
  const [categories, setCategories] = useState<Category[]>([]);
  const [latestAds, setLatestAds] = useState<Ad[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [categoriesRes, adsRes] = await Promise.all([
        api.get('/categories/top-level'),
        api.get('/ads?limit=8'),
      ]);
      setCategories(categoriesRes.data.slice(0, 6));
      setLatestAds(adsRes.data.data);
    } catch (error) {
      console.error('Failed to fetch data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      router.push(`/ads?search=${encodeURIComponent(searchQuery)}`);
    }
  };

  return (
    <>
      <Head>
        <title>دیوار - پلتفرم خرید و فروش</title>
        <meta name="description" content="پلتفرم پیشرفته خرید و فروش آنلاین" />
      </Head>

      {/* Hero Section */}
      <section className="relative py-20 px-4">
        <div className="container mx-auto max-w-4xl text-center">
          <h1 className="text-5xl md:text-6xl font-bold mb-6">
            <span className="gradient-text">خرید و فروش</span>
            <br />
            آسان، سریع و امن
          </h1>
          <p className="text-xl text-gray-400 mb-8">
            هزاران آگهی در دسته‌بندی‌های مختلف
          </p>

          {/* Search Bar */}
          <form onSubmit={handleSearch} className="max-w-2xl mx-auto">
            <div className="flex gap-4">
              <Input
                type="text"
                placeholder="دنبال چه چیزی هستید؟"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex-1"
              />
              <Button type="submit" variant="primary">
                جستجو
              </Button>
            </div>
          </form>
        </div>
      </section>

      {/* Categories */}
      <section className="py-12 px-4">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold mb-8 text-center">
            <span className="gradient-text">دسته‌بندی‌ها</span>
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {categories.map((category) => (
              <Link href={`/ads?categoryId=${category.id}`} key={category.id}>
                <Card hover className="text-center">
                  <div className="text-4xl mb-2">{category.icon || '📱'}</div>
                  <h3 className="font-medium">{category.name}</h3>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Latest Ads */}
      <section className="py-12 px-4">
        <div className="container mx-auto">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-3xl font-bold">
              <span className="gradient-text">جدیدترین آگهی‌ها</span>
            </h2>
            <Link href="/ads">
              <Button variant="outline" size="sm">
                مشاهده همه
              </Button>
            </Link>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[...Array(4)].map((_, i) => (
                <Card key={i} className="h-64 animate-pulse" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {latestAds.map((ad) => (
                <Link href={`/ads/${ad.id}`} key={ad.id}>
                  <Card hover>
                    <div className="aspect-video bg-gray-800 rounded-lg mb-4 flex items-center justify-center">
                      {ad.images && ad.images.length > 0 ? (
                        <img
                          src={ad.images[0].url}
                          alt={ad.title}
                          className="w-full h-full object-cover rounded-lg"
                        />
                      ) : (
                        <span className="text-4xl">📱</span>
                      )}
                    </div>
                    <h3 className="font-semibold mb-2 line-clamp-2">{ad.title}</h3>
                    <div className="flex justify-between items-center">
                      <span className="text-lg font-bold gradient-text">
                        {formatPrice(ad.price)} تومان
                      </span>
                      <span className="text-sm text-gray-400">
                        {formatRelativeTime(ad.createdAt)}
                      </span>
                    </div>
                  </Card>
                </Link>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4">
        <Card className="container mx-auto max-w-4xl text-center">
          <h2 className="text-4xl font-bold mb-4">
            <span className="gradient-text">آماده فروش هستید؟</span>
          </h2>
          <p className="text-gray-400 mb-8">
            به راحتی آگهی خود را ثبت کنید و به میلیون‌ها خریدار دسترسی پیدا کنید
          </p>
          <Link href="/ads/create">
            <Button variant="primary" size="lg">
              ثبت آگهی رایگان
            </Button>
          </Link>
        </Card>
      </section>

      {/* Stats */}
      <section className="py-12 px-4">
        <div className="container mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold gradient-text mb-2">10K+</div>
              <div className="text-gray-400">آگهی فعال</div>
            </div>
            <div>
              <div className="text-4xl font-bold gradient-text mb-2">50K+</div>
              <div className="text-gray-400">کاربر فعال</div>
            </div>
            <div>
              <div className="text-4xl font-bold gradient-text mb-2">100+</div>
              <div className="text-gray-400">دسته‌بندی</div>
            </div>
            <div>
              <div className="text-4xl font-bold gradient-text mb-2">99%</div>
              <div className="text-gray-400">رضایت کاربران</div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
