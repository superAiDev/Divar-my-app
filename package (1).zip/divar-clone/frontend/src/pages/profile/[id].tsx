import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import { Layout } from '../../components/layout';
import { Tabs, Badge, Spinner, Button, Modal } from '../../components/ui';
import { AdCard } from '../../components/ads/AdCard';
import api from '../../lib/api';
import { useAuth } from '../../hooks/useAuth';
import { formatDate } from '../../utils/format';

interface User {
  id: string;
  name: string;
  email?: string;
  phone: string;
  avatar?: string;
  bio?: string;
  createdAt: string;
}

interface Stats {
  totalAds: number;
  totalFavorites: number;
  totalReviews: number;
  memberSince: string;
}

const ProfilePage = () => {
  const router = useRouter();
  const { id } = router.query;
  const { user: currentUser } = useAuth();
  const [user, setUser] = useState<User | null>(null);
  const [stats, setStats] = useState<Stats | null>(null);
  const [userAds, setUserAds] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editModalOpen, setEditModalOpen] = useState(false);

  const isOwnProfile = currentUser?.id === id;

  useEffect(() => {
    if (id) {
      fetchUserProfile();
      fetchUserStats();
      fetchUserAds();
    }
  }, [id]);

  const fetchUserProfile = async () => {
    try {
      const response = await api.get(`/users/${id}`);
      setUser(response.data);
    } catch (error) {
      console.error('Error fetching user:', error);
    }
  };

  const fetchUserStats = async () => {
    try {
      const response = await api.get(`/users/${id}/stats`);
      setStats(response.data);
    } catch (error) {
      console.error('Error fetching stats:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchUserAds = async () => {
    try {
      const response = await api.get(`/ads?userId=${id}`);
      setUserAds(response.data.data);
    } catch (error) {
      console.error('Error fetching user ads:', error);
    }
  };

  if (loading) {
    return (
      <Layout>
        <Spinner fullScreen />
      </Layout>
    );
  }

  if (!user) {
    return (
      <Layout>
        <div className="flex flex-col items-center justify-center min-h-screen">
          <h1 className="text-2xl font-bold text-white mb-4">کاربر یافت نشد</h1>
          <Button onClick={() => router.push('/')}>بازگشت به صفحه اصلی</Button>
        </div>
      </Layout>
    );
  }

  const tabs = [
    {
      id: 'ads',
      label: `آگهی‌ها (${stats?.totalAds || 0})`,
      icon: (
        <svg fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
        </svg>
      ),
      content: (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {userAds.length > 0 ? (
            userAds.map((ad: any) => <AdCard key={ad.id} ad={ad} />)
          ) : (
            <div className="col-span-full text-center py-20 text-gray-400">
              هیچ آگهی یافت نشد
            </div>
          )}
        </div>
      ),
    },
    {
      id: 'about',
      label: 'درباره',
      icon: (
        <svg fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
        </svg>
      ),
      content: (
        <div className="space-y-4">
          {user.bio ? (
            <div>
              <h3 className="text-lg font-semibold text-white mb-2">بیوگرافی</h3>
              <p className="text-gray-300">{user.bio}</p>
            </div>
          ) : (
            <p className="text-gray-400">بیوگرافی وجود ندارد</p>
          )}

          <div className="grid grid-cols-2 gap-4 pt-4">
            <div>
              <span className="text-gray-400 text-sm">تعداد آگهی‌ها</span>
              <p className="text-2xl font-bold text-white">{stats?.totalAds || 0}</p>
            </div>
            <div>
              <span className="text-gray-400 text-sm">تعداد نظرات</span>
              <p className="text-2xl font-bold text-white">{stats?.totalReviews || 0}</p>
            </div>
          </div>
        </div>
      ),
    },
  ];

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        {/* Profile Header */}
        <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-2xl p-8 mb-8 border border-gray-700/50">
          <div className="flex items-start gap-6">
            <img
              src={user.avatar || '/default-avatar.png'}
              alt={user.name}
              className="w-32 h-32 rounded-full border-4 border-blue-500"
            />
            <div className="flex-1">
              <div className="flex items-center gap-4 mb-2">
                <h1 className="text-3xl font-bold text-white">{user.name}</h1>
                {isOwnProfile && (
                  <button
                    onClick={() => setEditModalOpen(true)}
                    className="px-4 py-2 bg-gray-700 hover:bg-gray-600 text-white rounded-lg transition"
                  >
                    ویرایش پروفایل
                  </button>
                )}
              </div>
              <p className="text-gray-400 mb-4">عضو از {formatDate(user.createdAt)}</p>

              <div className="flex gap-4">
                <div className="bg-gray-800/50 rounded-xl px-6 py-3">
                  <span className="text-gray-400 text-sm">آگهی‌ها</span>
                  <p className="text-xl font-bold text-white">{stats?.totalAds || 0}</p>
                </div>
                <div className="bg-gray-800/50 rounded-xl px-6 py-3">
                  <span className="text-gray-400 text-sm">علاقه‌مندی‌ها</span>
                  <p className="text-xl font-bold text-white">{stats?.totalFavorites || 0}</p>
                </div>
                <div className="bg-gray-800/50 rounded-xl px-6 py-3">
                  <span className="text-gray-400 text-sm">نظرات</span>
                  <p className="text-xl font-bold text-white">{stats?.totalReviews || 0}</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-2xl p-6 border border-gray-700/50">
          <Tabs tabs={tabs} />
        </div>
      </div>

      {/* Edit Profile Modal */}
      <Modal isOpen={editModalOpen} onClose={() => setEditModalOpen(false)} title="ویرایش پروفایل">
        <div className="space-y-4">
          <p className="text-gray-400">به‌زودی امکان ویرایش پروفایل فعال خواهد شد</p>
        </div>
      </Modal>
    </Layout>
  );
};

export default ProfilePage;
