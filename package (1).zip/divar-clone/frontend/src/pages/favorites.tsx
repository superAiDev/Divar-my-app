import React, { useState, useEffect } from 'react';
import { Layout } from '../components/layout';
import { AdCard } from '../components/ads/AdCard';
import { Spinner, Badge } from '../components/ui';
import api from '../lib/api';
import { useAuth } from '../hooks/useAuth';
import { useRouter } from 'next/router';

interface Ad {
  id: string;
  title: string;
  price: number;
  images: Array<{ url: string }>;
  location: { city: string };
  createdAt: string;
}

const FavoritesPage = () => {
  const router = useRouter();
  const { user, loading: authLoading } = useAuth();
  const [favorites, setFavorites] = useState<Ad[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!authLoading && !user) {
      router.push('/auth/login');
    } else if (user) {
      fetchFavorites();
    }
  }, [user, authLoading]);

  const fetchFavorites = async () => {
    try {
      const response = await api.get('/favorites');
      setFavorites(response.data.data.map((fav: any) => fav.ad));
    } catch (error) {
      console.error('Error fetching favorites:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleRemoveFavorite = async (adId: string) => {
    try {
      await api.delete(`/favorites/${adId}`);
      setFavorites(favorites.filter((ad) => ad.id !== adId));
    } catch (error) {
      console.error('Error removing favorite:', error);
    }
  };

  if (authLoading || loading) {
    return (
      <Layout>
        <Spinner fullScreen />
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">علاقه‌مندی‌ها</h1>
          <p className="text-gray-400">آگهی‌های ذخیره شده شما</p>
        </div>

        {favorites.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {favorites.map((ad) => (
              <div key={ad.id} className="relative">
                <AdCard ad={ad} />
                <button
                  onClick={() => handleRemoveFavorite(ad.id)}
                  className="absolute top-4 left-4 p-2 bg-red-500/80 hover:bg-red-600 text-white rounded-full transition z-10"
                >
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-20">
            <svg className="w-24 h-24 text-gray-600 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
            </svg>
            <h2 className="text-2xl font-bold text-white mb-2">هیچ آگهی ذخیره نشده</h2>
            <p className="text-gray-400 mb-6">آگهی‌های مورد علاقه خود را ذخیره کنید</p>
            <button
              onClick={() => router.push('/')}
              className="px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white rounded-xl font-medium transition"
            >
              مشاهده آگهی‌ها
            </button>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default FavoritesPage;
