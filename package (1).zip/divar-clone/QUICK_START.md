# 🚀 پلتفرم آگهی‌گذاری پیشرفته - دستورالعمل سریع

## در 3 دقیقه راه‌اندازی کنید!

```bash
# 1. ورود به پوشه پروژه
cd divar-clone

# 2. اجرای اسکریپت راه‌اندازی خودکار
chmod +x start.sh
./start.sh
```

✨ **همین!** سیستم شما آماده است.

---

## 🌐 آدرس‌ها

- **Frontend**: http://localhost:3000
- **Backend API**: http://localhost:4000
- **API Documentation**: http://localhost:4000/api/docs
- **MinIO Console**: http://localhost:9001

---

## 🔑 حساب ادمین پیش‌فرض

- **شماره موبایل**: 09123456789
- **کد OTP**: در حالت development هر کد 6 رقمی پذیرفته می‌شود

---

## ⚙️ تنظیمات پیشرفته

### SMS Provider

فایل `backend/.env` را ویرایش کنید:

```env
# برای Kavenegar
SMS_PROVIDER=kavenegar
KAVENEGAR_API_KEY=your_actual_api_key
KAVENEGAR_SENDER=10004346

# یا برای Ghasedak
SMS_PROVIDER=ghasedak
GHASEDAK_API_KEY=your_actual_api_key
```

### Payment Gateway

```env
# ZarinPal
ZARINPAL_MERCHANT_ID=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
ZARINPAL_SANDBOX=false

# IDPay
IDPAY_API_KEY=your_idpay_api_key
IDPAY_SANDBOX=false
```

### راه‌اندازی مجدد پس از تغییرات

```bash
docker-compose restart
```

---

## 🛠️ دستورات مفید

### مشاهده Logs

```bash
# تمام سرویس‌ها
docker-compose logs -f

# فقط Backend
docker-compose logs -f backend

# فقط Frontend
docker-compose logs -f frontend
```

### خاموش کردن سیستم

```bash
docker-compose down
```

### حذف کامل (شامل دیتابیس)

```bash
docker-compose down -v
```

### راه‌اندازی دوباره با Build جدید

```bash
docker-compose up -d --build
```

### ورود به Container

```bash
# Backend
docker-compose exec backend sh

# Frontend
docker-compose exec frontend sh

# Database
docker-compose exec postgres psql -U postgres -d divar
```

### Backup دیتابیس

```bash
docker-compose exec postgres pg_dump -U postgres divar > backup_$(date +%Y%m%d).sql
```

### Restore دیتابیس

```bash
cat backup_20250101.sql | docker-compose exec -T postgres psql -U postgres divar
```

---

## 📚 مستندات API

پس از راه‌اندازی، به آدرس زیر بروید:

http://localhost:4000/api/docs

در این صفحه Swagger:
- تمام Endpoints را مشاهده کنید
- API را به صورت مستقیم تست کنید
- Request/Response Models را ببینید

---

## 🚀 Deploy به Production

### آماده‌سازی

1. **تغییر Environment Variables**:
   - `JWT_ACCESS_SECRET` و `JWT_REFRESH_SECRET` را تغییر دهید
   - `DATABASE_PASSWORD` را قوی کنید
   - `REDIS_PASSWORD` تنظیم کنید
   - `NODE_ENV=production` قرار دهید

2. **تنظیم Domain**:
   ```env
   APP_URL=https://api.yourdomain.com
   FRONTEND_URL=https://yourdomain.com
   ```

3. **راه‌اندازی بر روی VPS**:

```bash
# نصب Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# Clone پروژه
git clone <your-repo-url>
cd divar-clone

# تنظیم .env
cp backend/.env.example backend/.env
nano backend/.env  # ویرایش کنید

# راه‌اندازی
./start.sh
```

4. **تنظیم Nginx Reverse Proxy**:

```nginx
server {
    listen 80;
    server_name yourdomain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}

server {
    listen 80;
    server_name api.yourdomain.com;

    location / {
        proxy_pass http://localhost:4000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

5. **نصب SSL (توصیه می‌شود)**:

```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d yourdomain.com -d api.yourdomain.com
```

---

## 🐞 عیب‌یابی

### خطای Database Connection

```bash
# بررسی سلامت دیتابیس
docker-compose exec postgres pg_isready

# Restart Database
docker-compose restart postgres
```

### خطای Redis Connection

```bash
# تست Redis
docker-compose exec redis redis-cli ping

# باید خروجی PONG باشد
```

### خطای MinIO

```bash
# بررسی وضعیت MinIO
curl http://localhost:9000/minio/health/live

# Restart MinIO
docker-compose restart minio
```

### Logs خطاها

```bash
# مشاهده خطاهای اخیر
docker-compose logs --tail=100 backend
```

---

## 🎓 منابع آموزشی

- [NestJS Documentation](https://docs.nestjs.com)
- [Next.js Documentation](https://nextjs.org/docs)
- [TypeORM Documentation](https://typeorm.io)
- [Docker Documentation](https://docs.docker.com)

---

## 💬 پشتیبانی

برای هر گونه سوال یا مشکل، با تیم توسعه تماس بگیرید.

---

## ✅ Checklist راه‌اندازی

- [ ] Docker و Docker Compose نصب شده
- [ ] فایل‌های .env کپی و تنظیم شده
- [ ] `./start.sh` اجرا شده
- [ ] Frontend در http://localhost:3000 باز می‌شود
- [ ] Backend API در http://localhost:4000 پاسخ می‌دهد
- [ ] Swagger Docs در http://localhost:4000/api/docs فعال است
- [ ] ورود با شماره 09123456789 کار می‌کند

---

## 🎉 آماده راه‌اندازی کسب و کار شماست!

این پلتفرم کاملاً عملیاتی و آماده برای Production است. موفق باشید! 🚀
