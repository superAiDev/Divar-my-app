# 🚀 راهنمای ساخت پروژه Divar Clone از صفر

اگر نمی‌توانید فایل ZIP را دانلود کنید، می‌توانید با دستورات زیر کل پروژه را در سیستم خودتان بسازید.

## پیش‌نیازها
```bash
# نصب Node.js (نسخه 18 یا بالاتر)
# نصب Git
```

## مرحله ۱: ساخت ساختار پروژه

```bash
# ساخت پوشه اصلی
mkdir divar-clone-complete
cd divar-clone-complete

# ساخت ساختار پوشه‌ها
mkdir -p divar-clone/backend
mkdir -p divar-clone/frontend
mkdir -p admin-panel
```

## مرحله ۲: دانلود فایل‌های Backend

فایل‌های backend را از مخزن اصلی کلون کنید یا دستی بسازید.

```bash
cd divar-clone/backend
npm init -y
```

## مرحله ۳: دانلود فایل‌های Frontend

```bash
cd ../frontend
npx create-next-app@latest . --typescript --tailwind --app
```

## مرحله ۴: دانلود Admin Panel

```bash
cd ../../admin-panel
npx create-next-app@latest . --typescript --tailwind --app
```

## مرحله ۵: فایل‌های Docker

فایل‌های Docker و docker-compose را در ریشه پروژه بسازید.

---

## ⚠️ توجه

این روش زمان‌بر است. **بهترین راه این است که فایل ZIP را دانلود کنید.**

## 🆘 راه‌حل‌های جایگزین

### روش ۱: استفاده از GitHub
اگر حساب GitHub دارید:
1. یک repository جدید بسازید
2. من فایل‌ها را push می‌کنم
3. شما آن را clone کنید

### روش ۲: Google Drive
اگر لینک Google Drive برای آپلود دارید، بدهید تا فایل را آنجا بگذارم.

### روش ۳: دریافت کد فایل به فایل
می‌توانم محتوای هر فایل را برایتان نمایش دهم و شما دستی کپی کنید.

---

کدام روش را ترجیح می‌دهید؟
