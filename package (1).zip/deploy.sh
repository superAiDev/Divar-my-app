#!/bin/bash

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}  Divar Clone - Production Deployment  ${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""

# Check if .env file exists
if [ ! -f .env ]; then
    echo -e "${RED}Error: .env file not found!${NC}"
    echo "Please create .env file from .env.example"
    exit 1
fi

echo -e "${YELLOW}Step 1: Stopping development containers...${NC}"
docker-compose down

echo ""
echo -e "${YELLOW}Step 2: Building production images...${NC}"
docker-compose -f docker-compose.prod.yml build --no-cache

echo ""
echo -e "${YELLOW}Step 3: Starting production services...${NC}"
docker-compose -f docker-compose.prod.yml up -d

echo ""
echo -e "${YELLOW}Step 4: Waiting for services to be ready...${NC}"
sleep 15

echo ""
echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}  Production Deployment Complete!  ${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""
echo -e "${GREEN}Services Status:${NC}"
docker-compose -f docker-compose.prod.yml ps
echo ""
