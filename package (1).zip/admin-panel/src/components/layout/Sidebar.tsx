'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { cn } from '@/lib/utils'
import {
  LayoutDashboard,
  Users,
  FileText,
  FolderTree,
  Image,
  DollarSign,
  Settings,
  LogOut,
  Menu,
  X,
} from 'lucide-react'
import { authService } from '@/services/auth.service'
import { useRouter } from 'next/navigation'
import { useState } from 'react'

const navigation = [
  { name: 'داشبورد', href: '/dashboard', icon: LayoutDashboard },
  { name: 'کاربران', href: '/dashboard/users', icon: Users },
  { name: 'آگهی‌ها', href: '/dashboard/ads', icon: FileText },
  { name: 'دسته‌بندی‌ها', href: '/dashboard/categories', icon: FolderTree },
  { name: 'بنرها', href: '/dashboard/banners', icon: Image },
  { name: 'مالی', href: '/dashboard/transactions', icon: DollarSign },
  { name: 'تنظیمات', href: '/dashboard/settings', icon: Settings },
]

export function Sidebar() {
  const pathname = usePathname()
  const router = useRouter()
  const [isMobileOpen, setIsMobileOpen] = useState(false)

  const handleLogout = () => {
    authService.logout()
    router.push('/login')
  }

  const sidebarContent = (
    <>
      {/* Logo */}
      <div className="p-6 border-b">
        <h1 className="text-2xl font-bold text-primary">پنل مدیریت دیوار</h1>
        <p className="text-sm text-muted-foreground mt-1">سیستم مدیریت جامع</p>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
        {navigation.map((item) => {
          const isActive = pathname === item.href
          return (
            <Link
              key={item.name}
              href={item.href}
              onClick={() => setIsMobileOpen(false)}
              className={cn(
                'flex items-center gap-3 px-4 py-3 text-sm font-medium rounded-lg transition-colors',
                isActive
                  ? 'bg-primary text-primary-foreground'
                  : 'text-muted-foreground hover:bg-muted hover:text-foreground'
              )}
            >
              <item.icon className="h-5 w-5" />
              {item.name}
            </Link>
          )
        })}
      </nav>

      {/* Logout */}
      <div className="p-4 border-t">
        <button
          onClick={handleLogout}
          className="flex items-center gap-3 w-full px-4 py-3 text-sm font-medium text-destructive hover:bg-destructive/10 rounded-lg transition-colors"
        >
          <LogOut className="h-5 w-5" />
          خروج از سیستم
        </button>
      </div>
    </>
  )

  return (
    <>
      {/* Mobile Menu Button */}
      <button
        className="lg:hidden fixed top-4 right-4 z-50 p-2 bg-white rounded-lg shadow-lg"
        onClick={() => setIsMobileOpen(!isMobileOpen)}
      >
        {isMobileOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
      </button>

      {/* Mobile Sidebar */}
      {isMobileOpen && (
        <>
          <div
            className="lg:hidden fixed inset-0 bg-black/50 z-40"
            onClick={() => setIsMobileOpen(false)}
          />
          <aside className="lg:hidden fixed right-0 top-0 bottom-0 w-64 bg-white border-l shadow-xl z-40 flex flex-col">
            {sidebarContent}
          </aside>
        </>
      )}

      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex fixed right-0 top-0 bottom-0 w-64 bg-white border-l shadow-sm flex-col">
        {sidebarContent}
      </aside>
    </>
  )
}
