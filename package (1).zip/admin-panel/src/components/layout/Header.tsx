'use client'

import { usePathname } from 'next/navigation'
import { authService } from '@/services/auth.service'
import { Bell, User } from 'lucide-react'

const pageTitles: Record<string, string> = {
  '/dashboard': 'داشبورد',
  '/dashboard/users': 'مدیریت کاربران',
  '/dashboard/ads': 'مدیریت آگهی‌ها',
  '/dashboard/categories': 'مدیریت دسته‌بندی‌ها',
  '/dashboard/banners': 'مدیریت بنرها',
  '/dashboard/transactions': 'مدیریت مالی',
  '/dashboard/settings': 'تنظیمات سیستم',
}

export function Header() {
  const pathname = usePathname()
  const username = authService.getUser()
  const pageTitle = pageTitles[pathname] || 'پنل مدیریت'

  return (
    <header className="bg-white border-b shadow-sm">
      <div className="px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">{pageTitle}</h2>
            <p className="text-sm text-muted-foreground mt-1">
              مدیریت و کنترل کامل سیستم
            </p>
          </div>

          <div className="flex items-center gap-4">
            {/* Notifications */}
            <button className="relative p-2 hover:bg-muted rounded-lg transition-colors">
              <Bell className="h-5 w-5 text-muted-foreground" />
              <span className="absolute top-1 left-1 h-2 w-2 bg-red-500 rounded-full" />
            </button>

            {/* User Profile */}
            <div className="flex items-center gap-3 px-3 py-2 bg-muted rounded-lg">
              <div className="text-right">
                <p className="text-sm font-medium">{username || 'مدیر سیستم'}</p>
                <p className="text-xs text-muted-foreground">مدیر ارشد</p>
              </div>
              <div className="h-10 w-10 bg-primary rounded-full flex items-center justify-center">
                <User className="h-5 w-5 text-primary-foreground" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  )
}
