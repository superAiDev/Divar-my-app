'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card'
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from 'recharts'
import type { ChartData } from '@/types'

interface UserGrowthChartProps {
  data: ChartData[]
}

export function UserGrowthChart({ data }: UserGrowthChartProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>رشد کاربران و آگوهی‌ها</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={350}>
          <BarChart data={data}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="users" fill="#10b981" name="کاربران" />
            <Bar dataKey="ads" fill="#f59e0b" name="آگهی‌ها" />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  )
}
