import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card'
import { Badge } from '@/components/ui/Badge'
import { formatDateTime } from '@/lib/utils'

interface Activity {
  id: string
  type: 'user' | 'ad' | 'transaction' | 'system'
  title: string
  description: string
  timestamp: string
}

interface RecentActivitiesProps {
  activities: Activity[]
}

const activityColors = {
  user: 'default' as const,
  ad: 'warning' as const,
  transaction: 'success' as const,
  system: 'secondary' as const,
}

const activityLabels = {
  user: 'کاربر',
  ad: 'آگهی',
  transaction: 'تراکنش',
  system: 'سیستم',
}

export function RecentActivities({ activities }: RecentActivitiesProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>فعالیت‌های اخیر</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {activities.map((activity) => (
            <div
              key={activity.id}
              className="flex items-start gap-4 pb-4 border-b last:border-0"
            >
              <Badge variant={activityColors[activity.type]}>
                {activityLabels[activity.type]}
              </Badge>
              <div className="flex-1">
                <h4 className="text-sm font-medium">{activity.title}</h4>
                <p className="text-xs text-muted-foreground mt-1">
                  {activity.description}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  {formatDateTime(activity.timestamp)}
                </p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
