import apiClient from '@/lib/api'
import type { User, ApiResponse, PaginatedResponse } from '@/types'

export const userService = {
  getAll: async (params?: {
    page?: number
    limit?: number
    search?: string
    role?: string
    status?: string
  }): Promise<PaginatedResponse<User>> => {
    const { data } = await apiClient.get('/users', { params })
    return data
  },

  getById: async (id: string): Promise<User> => {
    const { data } = await apiClient.get(`/users/${id}`)
    return data
  },

  create: async (userData: Partial<User>): Promise<User> => {
    const { data } = await apiClient.post('/users', userData)
    return data
  },

  update: async (id: string, userData: Partial<User>): Promise<User> => {
    const { data } = await apiClient.patch(`/users/${id}`, userData)
    return data
  },

  delete: async (id: string): Promise<ApiResponse> => {
    const { data } = await apiClient.delete(`/users/${id}`)
    return data
  },

  ban: async (id: string): Promise<User> => {
    const { data } = await apiClient.post(`/users/${id}/ban`)
    return data
  },

  unban: async (id: string): Promise<User> => {
    const { data } = await apiClient.post(`/users/${id}/unban`)
    return data
  },
}
