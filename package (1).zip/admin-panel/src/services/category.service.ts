import apiClient from '@/lib/api'
import type { Category, ApiResponse } from '@/types'

export const categoryService = {
  getAll: async (): Promise<Category[]> => {
    const { data } = await apiClient.get('/categories')
    return data
  },

  getById: async (id: string): Promise<Category> => {
    const { data } = await apiClient.get(`/categories/${id}`)
    return data
  },

  create: async (categoryData: Partial<Category>): Promise<Category> => {
    const { data } = await apiClient.post('/categories', categoryData)
    return data
  },

  update: async (id: string, categoryData: Partial<Category>): Promise<Category> => {
    const { data } = await apiClient.patch(`/categories/${id}`, categoryData)
    return data
  },

  delete: async (id: string): Promise<ApiResponse> => {
    const { data } = await apiClient.delete(`/categories/${id}`)
    return data
  },

  reorder: async (orders: { id: string; order: number }[]): Promise<ApiResponse> => {
    const { data } = await apiClient.post('/categories/reorder', { orders })
    return data
  },
}
