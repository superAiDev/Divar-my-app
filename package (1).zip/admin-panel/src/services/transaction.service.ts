import apiClient from '@/lib/api'
import type { Transaction, PaginatedResponse } from '@/types'

export const transactionService = {
  getAll: async (params?: {
    page?: number
    limit?: number
    type?: string
    status?: string
  }): Promise<PaginatedResponse<Transaction>> => {
    const { data } = await apiClient.get('/transactions', { params })
    return data
  },

  getById: async (id: string): Promise<Transaction> => {
    const { data } = await apiClient.get(`/transactions/${id}`)
    return data
  },

  getRevenue: async (period: '7d' | '30d' | '90d' | '1y' = '30d') => {
    const { data } = await apiClient.get('/transactions/revenue', {
      params: { period },
    })
    return data
  },
}
