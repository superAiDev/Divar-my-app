import apiClient from '@/lib/api'
import type { Banner, ApiResponse } from '@/types'

export const bannerService = {
  getAll: async (): Promise<Banner[]> => {
    const { data } = await apiClient.get('/banners')
    return data
  },

  getById: async (id: string): Promise<Banner> => {
    const { data } = await apiClient.get(`/banners/${id}`)
    return data
  },

  create: async (bannerData: Partial<Banner>): Promise<Banner> => {
    const { data } = await apiClient.post('/banners', bannerData)
    return data
  },

  update: async (id: string, bannerData: Partial<Banner>): Promise<Banner> => {
    const { data } = await apiClient.patch(`/banners/${id}`, bannerData)
    return data
  },

  delete: async (id: string): Promise<ApiResponse> => {
    const { data } = await apiClient.delete(`/banners/${id}`)
    return data
  },

  uploadImage: async (file: File): Promise<{ url: string }> => {
    const formData = new FormData()
    formData.append('file', file)
    const { data } = await apiClient.post('/upload', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    })
    return data
  },
}
