import apiClient from '@/lib/api'
import type { Ad, ApiResponse, PaginatedResponse } from '@/types'

export const adService = {
  getAll: async (params?: {
    page?: number
    limit?: number
    search?: string
    status?: string
    categoryId?: string
    featured?: boolean
  }): Promise<PaginatedResponse<Ad>> => {
    const { data } = await apiClient.get('/ads', { params })
    return data
  },

  getById: async (id: string): Promise<Ad> => {
    const { data } = await apiClient.get(`/ads/${id}`)
    return data
  },

  update: async (id: string, adData: Partial<Ad>): Promise<Ad> => {
    const { data } = await apiClient.patch(`/ads/${id}`, adData)
    return data
  },

  delete: async (id: string): Promise<ApiResponse> => {
    const { data } = await apiClient.delete(`/ads/${id}`)
    return data
  },

  approve: async (id: string): Promise<Ad> => {
    const { data } = await apiClient.post(`/ads/${id}/approve`)
    return data
  },

  reject: async (id: string, reason: string): Promise<Ad> => {
    const { data } = await apiClient.post(`/ads/${id}/reject`, { reason })
    return data
  },

  toggleFeatured: async (id: string): Promise<Ad> => {
    const { data } = await apiClient.post(`/ads/${id}/toggle-featured`)
    return data
  },
}
