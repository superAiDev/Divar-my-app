import Cookies from 'js-cookie'

const ADMIN_USERNAME = process.env.NEXT_PUBLIC_ADMIN_USERNAME || process.env.ADMIN_USERNAME || 'admin'
const ADMIN_PASSWORD = process.env.NEXT_PUBLIC_ADMIN_PASSWORD || process.env.ADMIN_PASSWORD || 'Admin@123456'

export const authService = {
  login: async (username: string, password: string): Promise<boolean> => {
    // Simple hardcoded authentication
    if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
      // Generate a simple token
      const token = btoa(`${username}:${Date.now()}`)
      Cookies.set('admin_token', token, { expires: 7 })
      Cookies.set('admin_user', username, { expires: 7 })
      return true
    }
    return false
  },

  logout: () => {
    Cookies.remove('admin_token')
    Cookies.remove('admin_user')
  },

  isAuthenticated: (): boolean => {
    return !!Cookies.get('admin_token')
  },

  getUser: (): string | null => {
    return Cookies.get('admin_user') || null
  },
}
