import apiClient from '@/lib/api'
import type { DashboardStats, ChartData } from '@/types'

export const dashboardService = {
  getStats: async (): Promise<DashboardStats> => {
    const { data } = await apiClient.get('/admin/stats')
    return data
  },

  getChartData: async (period: '7d' | '30d' | '90d' | '1y' = '30d'): Promise<ChartData[]> => {
    const { data } = await apiClient.get('/admin/chart-data', {
      params: { period },
    })
    return data
  },

  getRecentActivities: async (limit: number = 10) => {
    const { data } = await apiClient.get('/admin/activities', {
      params: { limit },
    })
    return data
  },
}
