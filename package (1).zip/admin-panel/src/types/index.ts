export interface User {
  id: string
  username: string
  email: string
  phone: string
  fullName: string
  role: 'user' | 'admin' | 'vip'
  status: 'active' | 'banned' | 'pending'
  avatar?: string
  createdAt: string
  updatedAt: string
  adsCount?: number
  favoriteCount?: number
}

export interface Ad {
  id: string
  title: string
  description: string
  price: number
  categoryId: string
  category?: Category
  userId: string
  user?: User
  images: string[]
  status: 'pending' | 'active' | 'rejected' | 'sold' | 'expired'
  featured: boolean
  viewCount: number
  city: string
  province: string
  createdAt: string
  updatedAt: string
}

export interface Category {
  id: string
  name: string
  slug: string
  icon: string
  parentId?: string
  parent?: Category
  children?: Category[]
  adsCount?: number
  order: number
  isActive: boolean
  createdAt: string
  updatedAt: string
}

export interface Banner {
  id: string
  title: string
  image: string
  link: string
  position: 'hero' | 'sidebar' | 'footer' | 'category'
  order: number
  isActive: boolean
  startDate: string
  endDate: string
  clicks: number
  impressions: number
  createdAt: string
  updatedAt: string
}

export interface Transaction {
  id: string
  userId: string
  user?: User
  adId?: string
  ad?: Ad
  type: 'promotion' | 'featured' | 'subscription' | 'commission'
  amount: number
  status: 'pending' | 'completed' | 'failed' | 'refunded'
  paymentMethod: 'online' | 'wallet' | 'card'
  description: string
  createdAt: string
  updatedAt: string
}

export interface DashboardStats {
  totalUsers: number
  totalAds: number
  totalRevenue: number
  pendingAds: number
  activeUsers: number
  todayRevenue: number
  userGrowth: number
  adsGrowth: number
  revenueGrowth: number
}

export interface ChartData {
  date: string
  users: number
  ads: number
  revenue: number
}

export interface Settings {
  siteName: string
  siteDescription: string
  siteKeywords: string
  logo: string
  favicon: string
  contactEmail: string
  contactPhone: string
  address: string
  socialMedia: {
    instagram?: string
    telegram?: string
    twitter?: string
    linkedin?: string
  }
  seo: {
    metaTitle: string
    metaDescription: string
    ogImage: string
  }
  features: {
    enableChat: boolean
    enableReviews: boolean
    enableFavorites: boolean
    requireEmailVerification: boolean
    requirePhoneVerification: boolean
  }
  ads: {
    defaultDuration: number
    maxImages: number
    maxDescriptionLength: number
    autoApprove: boolean
    featuredPrice: number
    promotionPrice: number
  }
}

export interface ApiResponse<T = any> {
  success: boolean
  data?: T
  message?: string
  error?: string
}

export interface PaginatedResponse<T> {
  data: T[]
  total: number
  page: number
  limit: number
  totalPages: number
}
