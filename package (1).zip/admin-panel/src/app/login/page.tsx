'use client'

import { useState, FormEvent } from 'react'
import { useRouter } from 'next/navigation'
import { authService } from '@/services/auth.service'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/Card'
import { LogIn, Shield } from 'lucide-react'

export default function LoginPage() {
  const router = useRouter()
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [isLoading, setIsLoading] = useState(false)

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault()
    setError('')
    setIsLoading(true)

    try {
      const success = await authService.login(username, password)
      if (success) {
        router.push('/dashboard')
      } else {
        setError('نام کاربری یا رمز عبور اشتباه است')
      }
    } catch (err) {
      setError('خطایی رخ داده است. لطفاً دوباره تلاش کنید.')
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100" dir="rtl">
      <div className="w-full max-w-md px-4">
        {/* Logo and Title */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-primary rounded-full mb-4">
            <Shield className="h-8 w-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900">پنل مدیریت دیوار</h1>
          <p className="text-gray-600 mt-2">سیستم مدیریت جامع و حرفه‌ای</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>ورود به سیستم</CardTitle>
            <CardDescription>
              لطفاً اطلاعات خود را وارد کنید
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              {error && (
                <div className="p-3 bg-red-50 border border-red-200 text-red-700 rounded-lg text-sm">
                  {error}
                </div>
              )}

              <div>
                <label htmlFor="username" className="block text-sm font-medium mb-2">
                  نام کاربری
                </label>
                <Input
                  id="username"
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="admin"
                  required
                  disabled={isLoading}
                />
              </div>

              <div>
                <label htmlFor="password" className="block text-sm font-medium mb-2">
                  رمز عبور
                </label>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  required
                  disabled={isLoading}
                />
              </div>

              <Button
                type="submit"
                className="w-full"
                disabled={isLoading}
              >
                {isLoading ? (
                  <span>در حال ورود...</span>
                ) : (
                  <>
                    <LogIn className="ml-2 h-4 w-4" />
                    ورود به پنل
                  </>
                )}
              </Button>
            </form>

            <div className="mt-6 p-4 bg-blue-50 rounded-lg">
              <p className="text-xs text-blue-900 font-medium mb-2">🔑 اطلاعات پیش‌فرض:</p>
              <p className="text-xs text-blue-700">نام کاربری: <code className="bg-white px-2 py-1 rounded">admin</code></p>
              <p className="text-xs text-blue-700 mt-1">رمز عبور: <code className="bg-white px-2 py-1 rounded">Admin@123456</code></p>
            </div>
          </CardContent>
        </Card>

        <p className="text-center text-sm text-gray-600 mt-6">
          &copy; 2025 Divar Clone. تمامی حقوق محفوظ است.
        </p>
      </div>
    </div>
  )
}
