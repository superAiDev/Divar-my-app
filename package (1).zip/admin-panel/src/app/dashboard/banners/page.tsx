'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { Badge } from '@/components/ui/Badge'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card'
import { Modal } from '@/components/ui/Modal'
import { Select } from '@/components/ui/Select'
import { Spinner } from '@/components/ui/Spinner'
import { Image as ImageIcon, Plus, Edit, Trash2, Eye, BarChart3 } from 'lucide-react'
import type { Banner } from '@/types'
import { formatDate } from '@/lib/utils'

const mockBanners: Banner[] = [
  {
    id: '1',
    title: 'بنر اصلی هوم پیج',
    image: 'https://via.placeholder.com/1200x400',
    link: '/featured',
    position: 'hero',
    order: 1,
    isActive: true,
    startDate: new Date().toISOString(),
    endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
    clicks: 1234,
    impressions: 45678,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: '2',
    title: 'بنر سایدبار',
    image: 'https://via.placeholder.com/300x600',
    link: '/promotions',
    position: 'sidebar',
    order: 1,
    isActive: true,
    startDate: new Date().toISOString(),
    endDate: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000).toISOString(),
    clicks: 567,
    impressions: 12345,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
]

const positionLabels = {
  hero: 'بنر اصلی',
  sidebar: 'سایدبار',
  footer: 'فوتر',
  category: 'صفحه دسته‌بندی',
}

export default function BannersPage() {
  const [banners, setBanners] = useState<Banner[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [selectedBanner, setSelectedBanner] = useState<Banner | null>(null)
  const [formData, setFormData] = useState({
    title: '',
    link: '',
    position: 'hero',
    startDate: '',
    endDate: '',
  })

  useEffect(() => {
    setTimeout(() => {
      setBanners(mockBanners)
      setIsLoading(false)
    }, 1000)
  }, [])

  const handleEdit = (banner: Banner) => {
    setSelectedBanner(banner)
    setFormData({
      title: banner.title,
      link: banner.link,
      position: banner.position,
      startDate: banner.startDate.split('T')[0],
      endDate: banner.endDate.split('T')[0],
    })
    setIsModalOpen(true)
  }

  const handleAddNew = () => {
    setSelectedBanner(null)
    setFormData({
      title: '',
      link: '',
      position: 'hero',
      startDate: new Date().toISOString().split('T')[0],
      endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    })
    setIsModalOpen(true)
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Spinner size="lg" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">مدیریت بنرها</h1>
          <p className="text-muted-foreground mt-1">کل بنرها: {banners.length}</p>
        </div>
        <Button onClick={handleAddNew}>
          <Plus className="ml-2 h-4 w-4" />
          افزودن بنر
        </Button>
      </div>

      {/* Banners List */}
      <div className="space-y-4">
        {banners.map((banner) => {
          const ctr = ((banner.clicks / banner.impressions) * 100).toFixed(2)
          return (
            <Card key={banner.id}>
              <CardContent className="p-6">
                <div className="flex gap-6">
                  {/* Banner Preview */}
                  <div className="flex-shrink-0">
                    <div className="w-48 h-32 bg-muted rounded-lg overflow-hidden">
                      <img
                        src={banner.image}
                        alt={banner.title}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  </div>

                  {/* Banner Info */}
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h3 className="font-bold text-lg">{banner.title}</h3>
                        <p className="text-sm text-muted-foreground mt-1">{banner.link}</p>
                      </div>
                      <div className="flex gap-2">
                        <Badge variant={banner.isActive ? 'success' : 'secondary'}>
                          {banner.isActive ? 'فعال' : 'غیرفعال'}
                        </Badge>
                        <Badge variant="outline">{positionLabels[banner.position]}</Badge>
                      </div>
                    </div>

                    <div className="grid grid-cols-4 gap-4 mb-4">
                      <div>
                        <p className="text-xs text-muted-foreground">نمایش‌ها</p>
                        <p className="text-lg font-semibold">{banner.impressions.toLocaleString('fa-IR')}</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">کلیک‌ها</p>
                        <p className="text-lg font-semibold">{banner.clicks.toLocaleString('fa-IR')}</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">CTR</p>
                        <p className="text-lg font-semibold">{ctr}%</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">انقضاء</p>
                        <p className="text-sm">{formatDate(banner.endDate)}</p>
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <Button size="sm" variant="outline" onClick={() => handleEdit(banner)}>
                        <Edit className="ml-2 h-4 w-4" />
                        ویرایش
                      </Button>
                      <Button size="sm" variant="outline">
                        <BarChart3 className="ml-2 h-4 w-4" />
                        آمار
                      </Button>
                      <Button size="sm" variant="destructive">
                        <Trash2 className="ml-2 h-4 w-4" />
                        حذف
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Add/Edit Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={selectedBanner ? 'ویرایش بنر' : 'افزودن بنر جدید'}
        size="lg"
      >
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">عنوان بنر</label>
            <Input
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              placeholder="مثال: تبلیغ ویژه فروش"
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-2">لینک</label>
            <Input
              value={formData.link}
              onChange={(e) => setFormData({ ...formData, link: e.target.value })}
              placeholder="/featured"
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-2">موقعیت نمایش</label>
            <Select
              options={[
                { value: 'hero', label: 'بنر اصلی' },
                { value: 'sidebar', label: 'سایدبار' },
                { value: 'footer', label: 'فوتر' },
                { value: 'category', label: 'صفحه دسته‌بندی' },
              ]}
              value={formData.position}
              onChange={(value) => setFormData({ ...formData, position: value as any })}
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">تاریخ شروع</label>
              <Input
                type="date"
                value={formData.startDate}
                onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">تاریخ پایان</label>
              <Input
                type="date"
                value={formData.endDate}
                onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium mb-2">آپلود تصویر</label>
            <div className="border-2 border-dashed border-muted rounded-lg p-8 text-center hover:border-primary transition-colors cursor-pointer">
              <ImageIcon className="h-12 w-12 mx-auto text-muted-foreground mb-2" />
              <p className="text-sm text-muted-foreground">تصویر بنر را بکشید یا کلیک کنید</p>
            </div>
          </div>
          <div className="flex gap-2 justify-end pt-4">
            <Button variant="outline" onClick={() => setIsModalOpen(false)}>
              انصراف
            </Button>
            <Button onClick={() => setIsModalOpen(false)}>
              {selectedBanner ? 'ذخیره تغییرات' : 'افزودن'}
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  )
}
