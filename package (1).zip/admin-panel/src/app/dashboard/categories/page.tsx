'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { Badge } from '@/components/ui/Badge'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card'
import { Modal } from '@/components/ui/Modal'
import { Spinner } from '@/components/ui/Spinner'
import { FolderTree, Plus, Edit, Trash2, GripVertical } from 'lucide-react'
import type { Category } from '@/types'

const mockCategories: Category[] = [
  { id: '1', name: 'وسایل نقلیه', slug: 'vehicles', icon: '🚗', order: 1, isActive: true, adsCount: 1234, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
  { id: '2', name: 'ملک و املاک', slug: 'real-estate', icon: '🏠', order: 2, isActive: true, adsCount: 892, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
  { id: '3', name: 'لوازم الکترونیکی', slug: 'electronics', icon: '📱', order: 3, isActive: true, adsCount: 1567, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
  { id: '4', name: 'لوازم خانه و آشپزخانه', slug: 'home', icon: '🛋️', order: 4, isActive: true, adsCount: 734, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
  { id: '5', name: 'خدمات', slug: 'services', icon: '🛠️', order: 5, isActive: true, adsCount: 456, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
  { id: '6', name: 'وسایل شخصی', slug: 'personal', icon: '👜', order: 6, isActive: true, adsCount: 289, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
  { id: '7', name: 'سرگرمی و فراغت', slug: 'entertainment', icon: '🎮', order: 7, isActive: true, adsCount: 345, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
]

export default function CategoriesPage() {
  const [categories, setCategories] = useState<Category[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [selectedCategory, setSelectedCategory] = useState<Category | null>(null)
  const [formData, setFormData] = useState({ name: '', slug: '', icon: '' })

  useEffect(() => {
    setTimeout(() => {
      setCategories(mockCategories)
      setIsLoading(false)
    }, 1000)
  }, [])

  const handleEdit = (category: Category) => {
    setSelectedCategory(category)
    setFormData({ name: category.name, slug: category.slug, icon: category.icon })
    setIsModalOpen(true)
  }

  const handleAddNew = () => {
    setSelectedCategory(null)
    setFormData({ name: '', slug: '', icon: '' })
    setIsModalOpen(true)
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Spinner size="lg" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">مدیریت دسته‌بندی‌ها</h1>
          <p className="text-muted-foreground mt-1">کل دسته‌بندی‌ها: {categories.length}</p>
        </div>
        <Button onClick={handleAddNew}>
          <Plus className="ml-2 h-4 w-4" />
          افزودن دسته‌بندی
        </Button>
      </div>

      {/* Categories Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {categories.map((category) => (
          <Card key={category.id} className="hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <div className="flex items-center gap-3">
                <div className="text-3xl">{category.icon}</div>
                <div>
                  <CardTitle className="text-lg">{category.name}</CardTitle>
                  <p className="text-sm text-muted-foreground">{category.slug}</p>
                </div>
              </div>
              <Badge variant="secondary">{category.adsCount} آگهی</Badge>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <GripVertical className="h-4 w-4 text-muted-foreground cursor-move" />
                  <span className="text-sm text-muted-foreground">ترتیب: {category.order}</span>
                </div>
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" onClick={() => handleEdit(category)}>
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button size="sm" variant="destructive">
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Add/Edit Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={selectedCategory ? 'ویرایش دسته‌بندی' : 'افزودن دسته‌بندی جدید'}
      >
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">نام دسته‌بندی</label>
            <Input
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="مثال: لوازم الکترونیکی"
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-2">نام مستعار (Slug)</label>
            <Input
              value={formData.slug}
              onChange={(e) => setFormData({ ...formData, slug: e.target.value })}
              placeholder="electronics"
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-2">آیکون (Emoji)</label>
            <Input
              value={formData.icon}
              onChange={(e) => setFormData({ ...formData, icon: e.target.value })}
              placeholder="📱"
              maxLength={2}
            />
          </div>
          <div className="flex gap-2 justify-end pt-4">
            <Button variant="outline" onClick={() => setIsModalOpen(false)}>
              انصراف
            </Button>
            <Button onClick={() => setIsModalOpen(false)}>
              {selectedCategory ? 'ذخیره تغییرات' : 'افزودن'}
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  )
}
