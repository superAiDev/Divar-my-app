'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { authService } from '@/services/auth.service'
import { ReactNode } from 'react'
import { DashboardLayout } from '@/components/layout'

export default function DashboardRootLayout({ children }: { children: ReactNode }) {
  const router = useRouter()

  useEffect(() => {
    if (!authService.isAuthenticated()) {
      router.push('/login')
    }
  }, [])

  if (!authService.isAuthenticated()) {
    return null
  }

  return <DashboardLayout>{children}</DashboardLayout>
}
