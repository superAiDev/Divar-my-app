'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { Badge } from '@/components/ui/Badge'
import { DataTable } from '@/components/ui/DataTable'
import { Pagination } from '@/components/ui/Pagination'
import { Select } from '@/components/ui/Select'
import { Modal } from '@/components/ui/Modal'
import { Spinner } from '@/components/ui/Spinner'
import { Search, UserPlus, Edit, Trash2, Ban, CheckCircle } from 'lucide-react'
import type { User } from '@/types'
import { formatDate } from '@/lib/utils'

// Mock data
const mockUsers: User[] = Array.from({ length: 50 }, (_, i) => ({
  id: `user-${i + 1}`,
  username: `user${i + 1}`,
  email: `user${i + 1}@example.com`,
  phone: `09${Math.floor(Math.random() * 1000000000)}`,
  fullName: `کاربر ${i + 1}`,
  role: ['user', 'admin', 'vip'][Math.floor(Math.random() * 3)] as any,
  status: ['active', 'banned', 'pending'][Math.floor(Math.random() * 3)] as any,
  createdAt: new Date(Date.now() - Math.random() * 90 * 24 * 60 * 60 * 1000).toISOString(),
  updatedAt: new Date().toISOString(),
  adsCount: Math.floor(Math.random() * 50),
  favoriteCount: Math.floor(Math.random() * 100),
}))

const roleLabels = {
  user: 'کاربر عادی',
  admin: 'مدیر',
  vip: 'VIP',
}

const statusLabels = {
  active: 'فعال',
  banned: 'مسدود',
  pending: 'در انتظار',
}

const statusVariants = {
  active: 'success' as const,
  banned: 'destructive' as const,
  pending: 'warning' as const,
}

export default function UsersPage() {
  const [users, setUsers] = useState<User[]>([])
  const [filteredUsers, setFilteredUsers] = useState<User[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [currentPage, setCurrentPage] = useState(1)
  const [searchTerm, setSearchTerm] = useState('')
  const [roleFilter, setRoleFilter] = useState('all')
  const [statusFilter, setStatusFilter] = useState('all')
  const [selectedUser, setSelectedUser] = useState<User | null>(null)
  const [isModalOpen, setIsModalOpen] = useState(false)

  const itemsPerPage = 10

  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      setUsers(mockUsers)
      setFilteredUsers(mockUsers)
      setIsLoading(false)
    }, 1000)
  }, [])

  useEffect(() => {
    let filtered = users

    if (searchTerm) {
      filtered = filtered.filter(
        (user) =>
          user.fullName.includes(searchTerm) ||
          user.email.includes(searchTerm) ||
          user.phone.includes(searchTerm)
      )
    }

    if (roleFilter !== 'all') {
      filtered = filtered.filter((user) => user.role === roleFilter)
    }

    if (statusFilter !== 'all') {
      filtered = filtered.filter((user) => user.status === statusFilter)
    }

    setFilteredUsers(filtered)
    setCurrentPage(1)
  }, [searchTerm, roleFilter, statusFilter, users])

  const totalPages = Math.ceil(filteredUsers.length / itemsPerPage)
  const paginatedUsers = filteredUsers.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  )

  const columns = [
    {
      header: 'نام کامل',
      accessor: (user: User) => (
        <div>
          <div className="font-medium">{user.fullName}</div>
          <div className="text-xs text-muted-foreground">{user.username}</div>
        </div>
      ),
    },
    {
      header: 'اطلاعات تماس',
      accessor: (user: User) => (
        <div className="text-sm">
          <div>{user.email}</div>
          <div className="text-muted-foreground">{user.phone}</div>
        </div>
      ),
    },
    {
      header: 'نقش',
      accessor: (user: User) => (
        <Badge variant={user.role === 'admin' ? 'default' : 'secondary'}>
          {roleLabels[user.role]}
        </Badge>
      ),
    },
    {
      header: 'وضعیت',
      accessor: (user: User) => (
        <Badge variant={statusVariants[user.status]}>
          {statusLabels[user.status]}
        </Badge>
      ),
    },
    {
      header: 'آگهی‌ها',
      accessor: (user: User) => user.adsCount || 0,
    },
    {
      header: 'تاریخ عضویت',
      accessor: (user: User) => formatDate(user.createdAt),
    },
    {
      header: 'عملیات',
      accessor: (user: User) => (
        <div className="flex gap-2">
          <Button
            size="sm"
            variant="outline"
            onClick={() => {
              setSelectedUser(user)
              setIsModalOpen(true)
            }}
          >
            <Edit className="h-4 w-4" />
          </Button>
          {user.status === 'active' ? (
            <Button size="sm" variant="destructive">
              <Ban className="h-4 w-4" />
            </Button>
          ) : (
            <Button size="sm" variant="outline">
              <CheckCircle className="h-4 w-4" />
            </Button>
          )}
        </div>
      ),
    },
  ]

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Spinner size="lg" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">مدیریت کاربران</h1>
          <p className="text-muted-foreground mt-1">
            کل کاربران: {filteredUsers.length}
          </p>
        </div>
        <Button>
          <UserPlus className="ml-2 h-4 w-4" />
          افزودن کاربر
        </Button>
      </div>

      {/* Filters */}
      <div className="bg-white p-4 rounded-lg border shadow-sm">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="md:col-span-2">
            <div className="relative">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="جستجو بر اساس نام، ایمیل یا شماره..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pr-10"
              />
            </div>
          </div>
          <Select
            options={[
              { value: 'all', label: 'همه نقش‌ها' },
              { value: 'user', label: 'کاربر عادی' },
              { value: 'admin', label: 'مدیر' },
              { value: 'vip', label: 'VIP' },
            ]}
            value={roleFilter}
            onChange={setRoleFilter}
          />
          <Select
            options={[
              { value: 'all', label: 'همه وضعیت‌ها' },
              { value: 'active', label: 'فعال' },
              { value: 'banned', label: 'مسدود' },
              { value: 'pending', label: 'در انتظار' },
            ]}
            value={statusFilter}
            onChange={setStatusFilter}
          />
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-lg border shadow-sm">
        <DataTable data={paginatedUsers} columns={columns} />
        {totalPages > 1 && (
          <div className="p-4 border-t">
            <Pagination
              currentPage={currentPage}
              totalPages={totalPages}
              onPageChange={setCurrentPage}
            />
          </div>
        )}
      </div>

      {/* Edit Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="ویرایش کاربر"
        size="lg"
      >
        {selectedUser && (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">نام کامل</label>
              <Input defaultValue={selectedUser.fullName} />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">ایمیل</label>
              <Input defaultValue={selectedUser.email} />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">شماره تماس</label>
              <Input defaultValue={selectedUser.phone} />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">نقش</label>
              <Select
                options={[
                  { value: 'user', label: 'کاربر عادی' },
                  { value: 'admin', label: 'مدیر' },
                  { value: 'vip', label: 'VIP' },
                ]}
                value={selectedUser.role}
                onChange={() => {}}
              />
            </div>
            <div className="flex gap-2 justify-end pt-4">
              <Button variant="outline" onClick={() => setIsModalOpen(false)}>
                انصراف
              </Button>
              <Button>ذخیره تغییرات</Button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  )
}
