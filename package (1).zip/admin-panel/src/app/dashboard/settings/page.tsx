'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/Card'
import { Badge } from '@/components/ui/Badge'
import { Save, Globe, Mail, Phone, MapPin, Share2, CreditCard, Shield } from 'lucide-react'

export default function SettingsPage() {
  const [isSaving, setIsSaving] = useState(false)
  const [settings, setSettings] = useState({
    siteName: 'دیوار',
    siteDescription: 'بزرگترین و بهترین پلتفرم خرید و فروش در ایران',
    contactEmail: 'info@divar.ir',
    contactPhone: '021-12345678',
    address: 'تهران، ایران',
    instagram: '@divar',
    telegram: '@divar',
    twitter: '@divar',
    linkedin: 'divar',
    enableChat: true,
    enableReviews: true,
    enableFavorites: true,
    requireEmailVerification: false,
    requirePhoneVerification: true,
    defaultAdDuration: '30',
    maxImages: '10',
    maxDescriptionLength: '2000',
    autoApprove: false,
    featuredPrice: '500000',
    promotionPrice: '300000',
  })

  const handleSave = () => {
    setIsSaving(true)
    setTimeout(() => {
      setIsSaving(false)
      alert('تنظیمات با موفقیت ذخیره شد!')
    }, 1000)
  }

  return (
    <div className="space-y-6 max-w-4xl">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold">تنظیمات سیستم</h1>
        <p className="text-muted-foreground mt-1">مدیریت و پیکربندی سیستم</p>
      </div>

      {/* Site Information */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Globe className="h-5 w-5" />
            اطلاعات سایت
          </CardTitle>
          <CardDescription>اطلاعات عمومی و سئو سایت</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">نام سایت</label>
            <Input
              value={settings.siteName}
              onChange={(e) => setSettings({ ...settings, siteName: e.target.value })}
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-2">توضیحات سایت</label>
            <Input
              value={settings.siteDescription}
              onChange={(e) => setSettings({ ...settings, siteDescription: e.target.value })}
            />
          </div>
        </CardContent>
      </Card>

      {/* Contact Information */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Phone className="h-5 w-5" />
            اطلاعات تماس
          </CardTitle>
          <CardDescription>راه‌های ارتباط با پشتیبانی</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">
              <Mail className="inline h-4 w-4 ml-2" />
              ایمیل
            </label>
            <Input
              type="email"
              value={settings.contactEmail}
              onChange={(e) => setSettings({ ...settings, contactEmail: e.target.value })}
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-2">
              <Phone className="inline h-4 w-4 ml-2" />
              تلفن
            </label>
            <Input
              value={settings.contactPhone}
              onChange={(e) => setSettings({ ...settings, contactPhone: e.target.value })}
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-2">
              <MapPin className="inline h-4 w-4 ml-2" />
              آدرس
            </label>
            <Input
              value={settings.address}
              onChange={(e) => setSettings({ ...settings, address: e.target.value })}
            />
          </div>
        </CardContent>
      </Card>

      {/* Social Media */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Share2 className="h-5 w-5" />
            شبکه‌های اجتماعی
          </CardTitle>
          <CardDescription>لینک‌های شبکه‌های اجتماعی</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">اینستاگرام</label>
              <Input
                value={settings.instagram}
                onChange={(e) => setSettings({ ...settings, instagram: e.target.value })}
                placeholder="@username"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">تلگرام</label>
              <Input
                value={settings.telegram}
                onChange={(e) => setSettings({ ...settings, telegram: e.target.value })}
                placeholder="@username"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">توییتر</label>
              <Input
                value={settings.twitter}
                onChange={(e) => setSettings({ ...settings, twitter: e.target.value })}
                placeholder="@username"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">لینکدین</label>
              <Input
                value={settings.linkedin}
                onChange={(e) => setSettings({ ...settings, linkedin: e.target.value })}
                placeholder="company-name"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Features */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            قابلیت‌های سیستم
          </CardTitle>
          <CardDescription>فعال یا غیرفعال سازی قابلیت‌ها</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">چت آنلاین</p>
              <p className="text-sm text-muted-foreground">فعال سازی سیستم چت</p>
            </div>
            <Badge variant={settings.enableChat ? 'success' : 'secondary'}>
              {settings.enableChat ? 'فعال' : 'غیرفعال'}
            </Badge>
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">نظرات و امتیازدهی</p>
              <p className="text-sm text-muted-foreground">فعال سازی سیستم ریویو</p>
            </div>
            <Badge variant={settings.enableReviews ? 'success' : 'secondary'}>
              {settings.enableReviews ? 'فعال' : 'غیرفعال'}
            </Badge>
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">علاقه‌مندی‌ها</p>
              <p className="text-sm text-muted-foreground">ذخیره آگهی‌ها در علاقه‌مندی‌ها</p>
            </div>
            <Badge variant={settings.enableFavorites ? 'success' : 'secondary'}>
              {settings.enableFavorites ? 'فعال' : 'غیرفعال'}
            </Badge>
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">تایید ایمیل</p>
              <p className="text-sm text-muted-foreground">الزامی بودن تایید ایمیل</p>
            </div>
            <Badge variant={settings.requireEmailVerification ? 'success' : 'secondary'}>
              {settings.requireEmailVerification ? 'فعال' : 'غیرفعال'}
            </Badge>
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">تایید شماره تماس</p>
              <p className="text-sm text-muted-foreground">الزامی بودن تایید موبایل</p>
            </div>
            <Badge variant={settings.requirePhoneVerification ? 'success' : 'secondary'}>
              {settings.requirePhoneVerification ? 'فعال' : 'غیرفعال'}
            </Badge>
          </div>
        </CardContent>
      </Card>

      {/* Ads Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CreditCard className="h-5 w-5" />
            تنظیمات آگهی‌ها
          </CardTitle>
          <CardDescription>تنظیمات مربوط به آگهی‌ها و قیمت‌گذاری</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">مدت نمایش (روز)</label>
              <Input
                type="number"
                value={settings.defaultAdDuration}
                onChange={(e) => setSettings({ ...settings, defaultAdDuration: e.target.value })}
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">حداکثر تصاویر</label>
              <Input
                type="number"
                value={settings.maxImages}
                onChange={(e) => setSettings({ ...settings, maxImages: e.target.value })}
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">حداکثر توضیحات</label>
              <Input
                type="number"
                value={settings.maxDescriptionLength}
                onChange={(e) => setSettings({ ...settings, maxDescriptionLength: e.target.value })}
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">تایید خودکار</label>
              <Badge variant={settings.autoApprove ? 'success' : 'warning'} className="mt-2">
                {settings.autoApprove ? 'فعال' : 'غیرفعال'}
              </Badge>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">قیمت آگهی ویژه (تومان)</label>
              <Input
                type="number"
                value={settings.featuredPrice}
                onChange={(e) => setSettings({ ...settings, featuredPrice: e.target.value })}
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">قیمت تبلیغ (تومان)</label>
              <Input
                type="number"
                value={settings.promotionPrice}
                onChange={(e) => setSettings({ ...settings, promotionPrice: e.target.value })}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button size="lg" onClick={handleSave} disabled={isSaving}>
          {isSaving ? (
            <span>در حال ذخیره...</span>
          ) : (
            <>
              <Save className="ml-2 h-5 w-5" />
              ذخیره تغییرات
            </>
          )}
        </Button>
      </div>
    </div>
  )
}
