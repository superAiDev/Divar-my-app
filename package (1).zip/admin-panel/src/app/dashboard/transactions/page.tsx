'use client'

import { useState, useEffect } from 'react'
import { Badge } from '@/components/ui/Badge'
import { DataTable } from '@/components/ui/DataTable'
import { Pagination } from '@/components/ui/Pagination'
import { Select } from '@/components/ui/Select'
import { Spinner } from '@/components/ui/Spinner'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card'
import { DollarSign, TrendingUp, CreditCard, Wallet } from 'lucide-react'
import type { Transaction } from '@/types'
import { formatDate, formatCurrency, formatNumber } from '@/lib/utils'

const mockTransactions: Transaction[] = Array.from({ length: 50 }, (_, i) => ({
  id: `txn-${i + 1}`,
  userId: `user-${Math.floor(Math.random() * 50) + 1}`,
  type: ['promotion', 'featured', 'subscription', 'commission'][Math.floor(Math.random() * 4)] as any,
  amount: Math.floor(Math.random() * 5000000) + 100000,
  status: ['pending', 'completed', 'failed', 'refunded'][Math.floor(Math.random() * 4)] as any,
  paymentMethod: ['online', 'wallet', 'card'][Math.floor(Math.random() * 3)] as any,
  description: `تراکنش شماره ${i + 1}`,
  createdAt: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toISOString(),
  updatedAt: new Date().toISOString(),
}))

const typeLabels = {
  promotion: 'تبلیغ',
  featured: 'آگهی ویژه',
  subscription: 'اشتراک',
  commission: 'کمیسیون',
}

const statusLabels = {
  pending: 'در انتظار',
  completed: 'تکمیل شده',
  failed: 'ناموفق',
  refunded: 'بازگشت وجه',
}

const statusVariants = {
  pending: 'warning' as const,
  completed: 'success' as const,
  failed: 'destructive' as const,
  refunded: 'secondary' as const,
}

export default function TransactionsPage() {
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [filteredTransactions, setFilteredTransactions] = useState<Transaction[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [currentPage, setCurrentPage] = useState(1)
  const [statusFilter, setStatusFilter] = useState('all')
  const [typeFilter, setTypeFilter] = useState('all')

  const itemsPerPage = 10

  useEffect(() => {
    setTimeout(() => {
      setTransactions(mockTransactions)
      setFilteredTransactions(mockTransactions)
      setIsLoading(false)
    }, 1000)
  }, [])

  useEffect(() => {
    let filtered = transactions

    if (statusFilter !== 'all') {
      filtered = filtered.filter((txn) => txn.status === statusFilter)
    }

    if (typeFilter !== 'all') {
      filtered = filtered.filter((txn) => txn.type === typeFilter)
    }

    setFilteredTransactions(filtered)
    setCurrentPage(1)
  }, [statusFilter, typeFilter, transactions])

  const totalPages = Math.ceil(filteredTransactions.length / itemsPerPage)
  const paginatedTransactions = filteredTransactions.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  )

  // Calculate stats
  const totalRevenue = transactions
    .filter((t) => t.status === 'completed')
    .reduce((sum, t) => sum + t.amount, 0)
  const pendingAmount = transactions
    .filter((t) => t.status === 'pending')
    .reduce((sum, t) => sum + t.amount, 0)
  const completedCount = transactions.filter((t) => t.status === 'completed').length

  const columns = [
    {
      header: 'شناسه تراکنش',
      accessor: (txn: Transaction) => (
        <div className="font-mono text-sm">{txn.id}</div>
      ),
    },
    {
      header: 'نوع',
      accessor: (txn: Transaction) => (
        <Badge variant="outline">{typeLabels[txn.type]}</Badge>
      ),
    },
    {
      header: 'مبلغ',
      accessor: (txn: Transaction) => (
        <span className="font-semibold">{formatCurrency(txn.amount)}</span>
      ),
    },
    {
      header: 'روش پرداخت',
      accessor: (txn: Transaction) => txn.paymentMethod,
    },
    {
      header: 'وضعیت',
      accessor: (txn: Transaction) => (
        <Badge variant={statusVariants[txn.status]}>
          {statusLabels[txn.status]}
        </Badge>
      ),
    },
    {
      header: 'تاریخ',
      accessor: (txn: Transaction) => formatDate(txn.createdAt),
    },
  ]

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Spinner size="lg" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold">مدیریت مالی</h1>
        <p className="text-muted-foreground mt-1">کل تراکنش‌ها: {filteredTransactions.length}</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              درآمد کل
            </CardTitle>
            <DollarSign className="h-5 w-5 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{formatCurrency(totalRevenue)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              در انتظار تسویه
            </CardTitle>
            <Wallet className="h-5 w-5 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{formatCurrency(pendingAmount)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              تراکنش‌های موفق
            </CardTitle>
            <CreditCard className="h-5 w-5 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{formatNumber(completedCount)}</div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <div className="bg-white p-4 rounded-lg border shadow-sm">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Select
            options={[
              { value: 'all', label: 'همه وضعیت‌ها' },
              { value: 'pending', label: 'در انتظار' },
              { value: 'completed', label: 'تکمیل شده' },
              { value: 'failed', label: 'ناموفق' },
              { value: 'refunded', label: 'بازگشت وجه' },
            ]}
            value={statusFilter}
            onChange={setStatusFilter}
          />
          <Select
            options={[
              { value: 'all', label: 'همه انواع' },
              { value: 'promotion', label: 'تبلیغ' },
              { value: 'featured', label: 'آگهی ویژه' },
              { value: 'subscription', label: 'اشتراک' },
              { value: 'commission', label: 'کمیسیون' },
            ]}
            value={typeFilter}
            onChange={setTypeFilter}
          />
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-lg border shadow-sm">
        <DataTable data={paginatedTransactions} columns={columns} />
        {totalPages > 1 && (
          <div className="p-4 border-t">
            <Pagination
              currentPage={currentPage}
              totalPages={totalPages}
              onPageChange={setCurrentPage}
            />
          </div>
        )}
      </div>
    </div>
  )
}
