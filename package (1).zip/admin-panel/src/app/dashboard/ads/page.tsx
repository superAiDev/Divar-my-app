'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { Badge } from '@/components/ui/Badge'
import { DataTable } from '@/components/ui/DataTable'
import { Pagination } from '@/components/ui/Pagination'
import { Select } from '@/components/ui/Select'
import { Modal } from '@/components/ui/Modal'
import { Spinner } from '@/components/ui/Spinner'
import { Search, Eye, CheckCircle, XCircle, Star, Trash2 } from 'lucide-react'
import type { Ad } from '@/types'
import { formatDate, formatCurrency } from '@/lib/utils'

// Mock data
const mockAds: Ad[] = Array.from({ length: 50 }, (_, i) => ({
  id: `ad-${i + 1}`,
  title: `آگهی شماره ${i + 1}`,
  description: `توضیحات آگهی شماره ${i + 1}`,
  price: Math.floor(Math.random() * 100000000) + 1000000,
  categoryId: `cat-${Math.floor(Math.random() * 5) + 1}`,
  userId: `user-${Math.floor(Math.random() * 50) + 1}`,
  images: [`/image${i + 1}.jpg`],
  status: ['pending', 'active', 'rejected', 'sold', 'expired'][Math.floor(Math.random() * 5)] as any,
  featured: Math.random() > 0.7,
  viewCount: Math.floor(Math.random() * 1000),
  city: 'تهران',
  province: 'تهران',
  createdAt: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toISOString(),
  updatedAt: new Date().toISOString(),
}))

const statusLabels = {
  pending: 'در انتظار تایید',
  active: 'فعال',
  rejected: 'رد شده',
  sold: 'فروخته شده',
  expired: 'منقضی شده',
}

const statusVariants = {
  pending: 'warning' as const,
  active: 'success' as const,
  rejected: 'destructive' as const,
  sold: 'secondary' as const,
  expired: 'outline' as const,
}

export default function AdsPage() {
  const [ads, setAds] = useState<Ad[]>([])
  const [filteredAds, setFilteredAds] = useState<Ad[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [currentPage, setCurrentPage] = useState(1)
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')
  const [selectedAd, setSelectedAd] = useState<Ad | null>(null)
  const [isModalOpen, setIsModalOpen] = useState(false)

  const itemsPerPage = 10

  useEffect(() => {
    setTimeout(() => {
      setAds(mockAds)
      setFilteredAds(mockAds)
      setIsLoading(false)
    }, 1000)
  }, [])

  useEffect(() => {
    let filtered = ads

    if (searchTerm) {
      filtered = filtered.filter((ad) => ad.title.includes(searchTerm))
    }

    if (statusFilter !== 'all') {
      filtered = filtered.filter((ad) => ad.status === statusFilter)
    }

    setFilteredAds(filtered)
    setCurrentPage(1)
  }, [searchTerm, statusFilter, ads])

  const totalPages = Math.ceil(filteredAds.length / itemsPerPage)
  const paginatedAds = filteredAds.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  )

  const columns = [
    {
      header: 'عنوان',
      accessor: (ad: Ad) => (
        <div>
          <div className="font-medium">{ad.title}</div>
          <div className="text-xs text-muted-foreground flex items-center gap-2 mt-1">
            <Eye className="h-3 w-3" />
            {ad.viewCount} بازدید
            {ad.featured && <Star className="h-3 w-3 text-yellow-500 fill-yellow-500" />}
          </div>
        </div>
      ),
    },
    {
      header: 'قیمت',
      accessor: (ad: Ad) => formatCurrency(ad.price),
    },
    {
      header: 'موقعیت',
      accessor: (ad: Ad) => `${ad.city}، ${ad.province}`,
    },
    {
      header: 'وضعیت',
      accessor: (ad: Ad) => (
        <Badge variant={statusVariants[ad.status]}>
          {statusLabels[ad.status]}
        </Badge>
      ),
    },
    {
      header: 'تاریخ ثبت',
      accessor: (ad: Ad) => formatDate(ad.createdAt),
    },
    {
      header: 'عملیات',
      accessor: (ad: Ad) => (
        <div className="flex gap-2">
          <Button
            size="sm"
            variant="outline"
            onClick={() => {
              setSelectedAd(ad)
              setIsModalOpen(true)
            }}
          >
            <Eye className="h-4 w-4" />
          </Button>
          {ad.status === 'pending' && (
            <>
              <Button size="sm" variant="outline">
                <CheckCircle className="h-4 w-4 text-green-600" />
              </Button>
              <Button size="sm" variant="destructive">
                <XCircle className="h-4 w-4" />
              </Button>
            </>
          )}
          <Button size="sm" variant="destructive">
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      ),
    },
  ]

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Spinner size="lg" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold">مدیریت آگهی‌ها</h1>
        <p className="text-muted-foreground mt-1">
          کل آگهی‌ها: {filteredAds.length} | در انتظار: {ads.filter(a => a.status === 'pending').length}
        </p>
      </div>

      {/* Filters */}
      <div className="bg-white p-4 rounded-lg border shadow-sm">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="md:col-span-2">
            <div className="relative">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="جستجو بر اساس عنوان..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pr-10"
              />
            </div>
          </div>
          <Select
            options={[
              { value: 'all', label: 'همه وضعیت‌ها' },
              { value: 'pending', label: 'در انتظار تایید' },
              { value: 'active', label: 'فعال' },
              { value: 'rejected', label: 'رد شده' },
              { value: 'sold', label: 'فروخته شده' },
              { value: 'expired', label: 'منقضی شده' },
            ]}
            value={statusFilter}
            onChange={setStatusFilter}
          />
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-lg border shadow-sm">
        <DataTable data={paginatedAds} columns={columns} />
        {totalPages > 1 && (
          <div className="p-4 border-t">
            <Pagination
              currentPage={currentPage}
              totalPages={totalPages}
              onPageChange={setCurrentPage}
            />
          </div>
        )}
      </div>

      {/* View Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="جزئیات آگهی"
        size="xl"
      >
        {selectedAd && (
          <div className="space-y-4">
            <div>
              <h3 className="font-bold text-lg">{selectedAd.title}</h3>
              <Badge variant={statusVariants[selectedAd.status]} className="mt-2">
                {statusLabels[selectedAd.status]}
              </Badge>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">{selectedAd.description}</p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm font-medium">قیمت:</p>
                <p className="text-lg font-bold text-primary">{formatCurrency(selectedAd.price)}</p>
              </div>
              <div>
                <p className="text-sm font-medium">بازدیدها:</p>
                <p className="text-lg">{selectedAd.viewCount}</p>
              </div>
              <div>
                <p className="text-sm font-medium">موقعیت:</p>
                <p>{selectedAd.city}، {selectedAd.province}</p>
              </div>
              <div>
                <p className="text-sm font-medium">تاریخ ثبت:</p>
                <p>{formatDate(selectedAd.createdAt)}</p>
              </div>
            </div>
            {selectedAd.status === 'pending' && (
              <div className="flex gap-2 justify-end pt-4 border-t">
                <Button variant="destructive">
                  <XCircle className="ml-2 h-4 w-4" />
                  رد آگهی
                </Button>
                <Button>
                  <CheckCircle className="ml-2 h-4 w-4" />
                  تایید آگهی
                </Button>
              </div>
            )}
          </div>
        )}
      </Modal>
    </div>
  )
}
