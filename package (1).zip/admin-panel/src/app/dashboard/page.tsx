'use client'

import { useEffect, useState } from 'react'
import { Users, FileText, DollarSign, TrendingUp, Clock, CheckCircle } from 'lucide-react'
import { StatCard } from '@/components/dashboard/StatCard'
import { RevenueChart } from '@/components/dashboard/RevenueChart'
import { UserGrowthChart } from '@/components/dashboard/UserGrowthChart'
import { RecentActivities } from '@/components/dashboard/RecentActivities'
import { Spinner } from '@/components/ui/Spinner'
import { formatNumber, formatCurrency } from '@/lib/utils'
import type { DashboardStats, ChartData } from '@/types'

// Mock data - در محیط واقعی از API دریافت می‌شود
const mockStats: DashboardStats = {
  totalUsers: 12453,
  totalAds: 8921,
  totalRevenue: 125000000,
  pendingAds: 47,
  activeUsers: 3421,
  todayRevenue: 2500000,
  userGrowth: 12.5,
  adsGrowth: 8.3,
  revenueGrowth: 15.2,
}

const mockChartData: ChartData[] = [
  { date: '1402/07/01', users: 120, ads: 85, revenue: 3200000 },
  { date: '1402/07/05', users: 145, ads: 102, revenue: 4100000 },
  { date: '1402/07/10', users: 178, ads: 125, revenue: 5300000 },
  { date: '1402/07/15', users: 203, ads: 148, revenue: 6200000 },
  { date: '1402/07/20', users: 245, ads: 178, revenue: 7500000 },
  { date: '1402/07/25', users: 289, ads: 210, revenue: 8900000 },
  { date: 'امروز', users: 321, ads: 245, revenue: 10200000 },
]

const mockActivities = [
  {
    id: '1',
    type: 'user' as const,
    title: 'کاربر جدید ثبت‌نام کرد',
    description: 'علی محمدی عضو سایت شد',
    timestamp: new Date().toISOString(),
  },
  {
    id: '2',
    type: 'ad' as const,
    title: 'آگهی جدید در انتظار تایید',
    description: 'فروش خودروی پژو 206',
    timestamp: new Date(Date.now() - 300000).toISOString(),
  },
  {
    id: '3',
    type: 'transaction' as const,
    title: 'تراکنش موفق',
    description: 'پرداخت 500,000 تومان برای آگهی ویژه',
    timestamp: new Date(Date.now() - 600000).toISOString(),
  },
  {
    id: '4',
    type: 'ad' as const,
    title: 'آگهی تایید شد',
    description: 'اجاره آپارتمان در تهران',
    timestamp: new Date(Date.now() - 900000).toISOString(),
  },
  {
    id: '5',
    type: 'system' as const,
    title: 'باکآپ خودکار',
    description: 'باکآپ دیتابیس با موفقیت انجام شد',
    timestamp: new Date(Date.now() - 1200000).toISOString(),
  },
]

export default function DashboardPage() {
  const [isLoading, setIsLoading] = useState(true)
  const [stats, setStats] = useState<DashboardStats | null>(null)

  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      setStats(mockStats)
      setIsLoading(false)
    }, 1000)
  }, [])

  if (isLoading || !stats) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Spinner size="lg" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="کل کاربران"
          value={formatNumber(stats.totalUsers)}
          icon={Users}
          trend={{ value: stats.userGrowth, label: 'نسبت به ماه قبل' }}
        />
        <StatCard
          title="کل آگهی‌ها"
          value={formatNumber(stats.totalAds)}
          icon={FileText}
          trend={{ value: stats.adsGrowth, label: 'نسبت به ماه قبل' }}
        />
        <StatCard
          title="درآمد کل"
          value={formatCurrency(stats.totalRevenue)}
          icon={DollarSign}
          trend={{ value: stats.revenueGrowth, label: 'نسبت به ماه قبل' }}
        />
        <StatCard
          title="آگهی‌های در انتظار"
          value={formatNumber(stats.pendingAds)}
          icon={Clock}
          className="border-orange-200 bg-orange-50"
        />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <RevenueChart data={mockChartData} />
        <UserGrowthChart data={mockChartData} />
      </div>

      {/* Recent Activities */}
      <RecentActivities activities={mockActivities} />
    </div>
  )
}
