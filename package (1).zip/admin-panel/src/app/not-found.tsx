import Link from 'next/link'
import { FileQuestion } from 'lucide-react'
import { Button } from '@/components/ui/Button'

export default function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100" dir="rtl">
      <div className="text-center">
        <div className="inline-flex items-center justify-center w-24 h-24 bg-primary/10 rounded-full mb-8">
          <FileQuestion className="h-12 w-12 text-primary" />
        </div>
        <h1 className="text-6xl font-bold text-gray-900 mb-4">404</h1>
        <p className="text-xl text-gray-600 mb-2">صفحه مورد نظر یافت نشد</p>
        <p className="text-gray-500 mb-8">ممکن است این صفحه حذف شده یا آدرس آن تغییر کرده باشد</p>
        <Link href="/dashboard">
          <Button size="lg">بازگشت به داشبورد</Button>
        </Link>
      </div>
    </div>
  )
}
