# Admin Panel - Divar Clone

## 🚀 Quick Start

### Installation
```bash
cd admin-panel
npm install
```

### Development
```bash
npm run dev
```

Admin panel will be available at: `http://localhost:3001`

### Default Credentials
- **Username:** `admin`
- **Password:** `Admin@123456`

## 📁 Project Structure

```
admin-panel/
├── src/
│   ├── app/              # Next.js App Router pages
│   ├── components/       # React components
│   ├── lib/             # Utilities and configurations
│   ├── hooks/           # Custom React hooks
│   ├── services/        # API services
│   └── types/           # TypeScript types
├── public/              # Static assets
└── package.json
```

## 🔑 Features

- ✅ Real-time Dashboard Analytics
- ✅ User Management (CRUD)
- ✅ Advertisement Management
- ✅ Category Management
- ✅ Banner Management
- ✅ Financial Reports
- ✅ System Settings
- ✅ Dark Mode Support
- ✅ Responsive Design
- ✅ Advanced Data Tables
- ✅ Interactive Charts

## 🔧 Configuration

Edit `.env.local` to change:
- Admin credentials
- API base URL
- App settings

## 🛠️ Tech Stack

- **Framework:** Next.js 14 (App Router)
- **Language:** TypeScript
- **Styling:** Tailwind CSS
- **UI Components:** Custom + shadcn/ui inspired
- **Data Fetching:** TanStack Query
- **Charts:** Recharts
- **Forms:** React Hook Form + Zod
- **Icons:** Lucide React

## 📦 Build for Production

```bash
npm run build
npm start
```
